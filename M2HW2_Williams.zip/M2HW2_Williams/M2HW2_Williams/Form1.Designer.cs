﻿namespace M2HW2_Williams
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.uppercaseAButton = new System.Windows.Forms.Button();
            this.lowerAButton = new System.Windows.Forms.Button();
            this.lowercaseAnButton = new System.Windows.Forms.Button();
            this.capitializedAnButton = new System.Windows.Forms.Button();
            this.capitializedTheButton = new System.Windows.Forms.Button();
            this.lowercaseTheButton = new System.Windows.Forms.Button();
            this.manButton = new System.Windows.Forms.Button();
            this.sentenceLabel = new System.Windows.Forms.Label();
            this.womanButton = new System.Windows.Forms.Button();
            this.dogButton = new System.Windows.Forms.Button();
            this.catButton = new System.Windows.Forms.Button();
            this.carButton = new System.Windows.Forms.Button();
            this.bicycleButton = new System.Windows.Forms.Button();
            this.beautifulButton = new System.Windows.Forms.Button();
            this.bigButton = new System.Windows.Forms.Button();
            this.smallButton = new System.Windows.Forms.Button();
            this.strangeButton = new System.Windows.Forms.Button();
            this.lookedButton = new System.Windows.Forms.Button();
            this.rodeButton = new System.Windows.Forms.Button();
            this.spokeButton = new System.Windows.Forms.Button();
            this.laughedButton = new System.Windows.Forms.Button();
            this.droveButton = new System.Windows.Forms.Button();
            this.spaceButton = new System.Windows.Forms.Button();
            this.periodButton = new System.Windows.Forms.Button();
            this.exclamationButton = new System.Windows.Forms.Button();
            this.clearButton = new System.Windows.Forms.Button();
            this.exitButton = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // uppercaseAButton
            // 
            this.uppercaseAButton.Location = new System.Drawing.Point(165, 12);
            this.uppercaseAButton.Name = "uppercaseAButton";
            this.uppercaseAButton.Size = new System.Drawing.Size(44, 36);
            this.uppercaseAButton.TabIndex = 0;
            this.uppercaseAButton.Text = "A";
            this.uppercaseAButton.UseVisualStyleBackColor = true;
            this.uppercaseAButton.Click += new System.EventHandler(this.uppercaseAButton_Click);
            // 
            // lowerAButton
            // 
            this.lowerAButton.Location = new System.Drawing.Point(215, 12);
            this.lowerAButton.Name = "lowerAButton";
            this.lowerAButton.Size = new System.Drawing.Size(44, 36);
            this.lowerAButton.TabIndex = 1;
            this.lowerAButton.Text = "a";
            this.lowerAButton.UseVisualStyleBackColor = true;
            this.lowerAButton.Click += new System.EventHandler(this.lowerAButton_Click);
            // 
            // lowercaseAnButton
            // 
            this.lowercaseAnButton.Location = new System.Drawing.Point(315, 12);
            this.lowercaseAnButton.Name = "lowercaseAnButton";
            this.lowercaseAnButton.Size = new System.Drawing.Size(44, 36);
            this.lowercaseAnButton.TabIndex = 3;
            this.lowercaseAnButton.Text = "an";
            this.lowercaseAnButton.UseVisualStyleBackColor = true;
            this.lowercaseAnButton.Click += new System.EventHandler(this.lowercaseAnButton_Click);
            // 
            // capitializedAnButton
            // 
            this.capitializedAnButton.Location = new System.Drawing.Point(265, 12);
            this.capitializedAnButton.Name = "capitializedAnButton";
            this.capitializedAnButton.Size = new System.Drawing.Size(44, 36);
            this.capitializedAnButton.TabIndex = 2;
            this.capitializedAnButton.Text = "An";
            this.capitializedAnButton.UseVisualStyleBackColor = true;
            this.capitializedAnButton.Click += new System.EventHandler(this.capitializedAnButton_Click);
            // 
            // capitializedTheButton
            // 
            this.capitializedTheButton.Location = new System.Drawing.Point(365, 12);
            this.capitializedTheButton.Name = "capitializedTheButton";
            this.capitializedTheButton.Size = new System.Drawing.Size(44, 36);
            this.capitializedTheButton.TabIndex = 4;
            this.capitializedTheButton.Text = "The";
            this.capitializedTheButton.UseVisualStyleBackColor = true;
            this.capitializedTheButton.Click += new System.EventHandler(this.capitializedTheButton_Click);
            // 
            // lowercaseTheButton
            // 
            this.lowercaseTheButton.Location = new System.Drawing.Point(415, 12);
            this.lowercaseTheButton.Name = "lowercaseTheButton";
            this.lowercaseTheButton.Size = new System.Drawing.Size(44, 36);
            this.lowercaseTheButton.TabIndex = 5;
            this.lowercaseTheButton.Text = "the";
            this.lowercaseTheButton.UseVisualStyleBackColor = true;
            this.lowercaseTheButton.Click += new System.EventHandler(this.lowercaseTheButton_Click);
            // 
            // manButton
            // 
            this.manButton.Location = new System.Drawing.Point(123, 54);
            this.manButton.Name = "manButton";
            this.manButton.Size = new System.Drawing.Size(52, 36);
            this.manButton.TabIndex = 6;
            this.manButton.Text = "man";
            this.manButton.UseVisualStyleBackColor = true;
            this.manButton.Click += new System.EventHandler(this.manButton_Click);
            // 
            // sentenceLabel
            // 
            this.sentenceLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.sentenceLabel.Location = new System.Drawing.Point(12, 283);
            this.sentenceLabel.Name = "sentenceLabel";
            this.sentenceLabel.Size = new System.Drawing.Size(609, 23);
            this.sentenceLabel.TabIndex = 7;
            this.sentenceLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // womanButton
            // 
            this.womanButton.Location = new System.Drawing.Point(181, 54);
            this.womanButton.Name = "womanButton";
            this.womanButton.Size = new System.Drawing.Size(60, 36);
            this.womanButton.TabIndex = 8;
            this.womanButton.Text = "woman";
            this.womanButton.UseVisualStyleBackColor = true;
            this.womanButton.Click += new System.EventHandler(this.womanButton_Click);
            // 
            // dogButton
            // 
            this.dogButton.Location = new System.Drawing.Point(247, 54);
            this.dogButton.Name = "dogButton";
            this.dogButton.Size = new System.Drawing.Size(44, 36);
            this.dogButton.TabIndex = 9;
            this.dogButton.Text = "dog";
            this.dogButton.UseVisualStyleBackColor = true;
            this.dogButton.Click += new System.EventHandler(this.dogButton_Click);
            // 
            // catButton
            // 
            this.catButton.Location = new System.Drawing.Point(297, 54);
            this.catButton.Name = "catButton";
            this.catButton.Size = new System.Drawing.Size(55, 36);
            this.catButton.TabIndex = 10;
            this.catButton.Text = "cat";
            this.catButton.UseVisualStyleBackColor = true;
            this.catButton.Click += new System.EventHandler(this.catButton_Click);
            // 
            // carButton
            // 
            this.carButton.Location = new System.Drawing.Point(358, 54);
            this.carButton.Name = "carButton";
            this.carButton.Size = new System.Drawing.Size(51, 36);
            this.carButton.TabIndex = 11;
            this.carButton.Text = "car";
            this.carButton.UseVisualStyleBackColor = true;
            this.carButton.Click += new System.EventHandler(this.carButton_Click);
            // 
            // bicycleButton
            // 
            this.bicycleButton.Location = new System.Drawing.Point(415, 54);
            this.bicycleButton.Name = "bicycleButton";
            this.bicycleButton.Size = new System.Drawing.Size(76, 36);
            this.bicycleButton.TabIndex = 12;
            this.bicycleButton.Text = "bicycle";
            this.bicycleButton.UseVisualStyleBackColor = true;
            this.bicycleButton.Click += new System.EventHandler(this.bicycleButton_Click);
            // 
            // beautifulButton
            // 
            this.beautifulButton.Location = new System.Drawing.Point(191, 96);
            this.beautifulButton.Name = "beautifulButton";
            this.beautifulButton.Size = new System.Drawing.Size(68, 36);
            this.beautifulButton.TabIndex = 13;
            this.beautifulButton.Text = "beautiful";
            this.beautifulButton.UseVisualStyleBackColor = true;
            this.beautifulButton.Click += new System.EventHandler(this.beautifulButton_Click);
            // 
            // bigButton
            // 
            this.bigButton.Location = new System.Drawing.Point(265, 96);
            this.bigButton.Name = "bigButton";
            this.bigButton.Size = new System.Drawing.Size(52, 36);
            this.bigButton.TabIndex = 14;
            this.bigButton.Text = "big";
            this.bigButton.UseVisualStyleBackColor = true;
            this.bigButton.Click += new System.EventHandler(this.bigButton_Click);
            // 
            // smallButton
            // 
            this.smallButton.Location = new System.Drawing.Point(323, 96);
            this.smallButton.Name = "smallButton";
            this.smallButton.Size = new System.Drawing.Size(44, 36);
            this.smallButton.TabIndex = 15;
            this.smallButton.Text = "small";
            this.smallButton.UseVisualStyleBackColor = true;
            this.smallButton.Click += new System.EventHandler(this.smallButton_Click);
            // 
            // strangeButton
            // 
            this.strangeButton.Location = new System.Drawing.Point(373, 96);
            this.strangeButton.Name = "strangeButton";
            this.strangeButton.Size = new System.Drawing.Size(62, 36);
            this.strangeButton.TabIndex = 16;
            this.strangeButton.Text = "strange";
            this.strangeButton.UseVisualStyleBackColor = true;
            this.strangeButton.Click += new System.EventHandler(this.strangeButton_Click);
            // 
            // lookedButton
            // 
            this.lookedButton.Location = new System.Drawing.Point(149, 138);
            this.lookedButton.Name = "lookedButton";
            this.lookedButton.Size = new System.Drawing.Size(60, 36);
            this.lookedButton.TabIndex = 17;
            this.lookedButton.Text = "looked at";
            this.lookedButton.UseVisualStyleBackColor = true;
            this.lookedButton.Click += new System.EventHandler(this.lookedButton_Click);
            // 
            // rodeButton
            // 
            this.rodeButton.Location = new System.Drawing.Point(215, 138);
            this.rodeButton.Name = "rodeButton";
            this.rodeButton.Size = new System.Drawing.Size(55, 36);
            this.rodeButton.TabIndex = 18;
            this.rodeButton.Text = "rode";
            this.rodeButton.UseVisualStyleBackColor = true;
            this.rodeButton.Click += new System.EventHandler(this.rodeButton_Click);
            // 
            // spokeButton
            // 
            this.spokeButton.Location = new System.Drawing.Point(276, 138);
            this.spokeButton.Name = "spokeButton";
            this.spokeButton.Size = new System.Drawing.Size(70, 36);
            this.spokeButton.TabIndex = 19;
            this.spokeButton.Text = "spoke to";
            this.spokeButton.UseVisualStyleBackColor = true;
            this.spokeButton.Click += new System.EventHandler(this.spokeButton_Click);
            // 
            // laughedButton
            // 
            this.laughedButton.Location = new System.Drawing.Point(352, 138);
            this.laughedButton.Name = "laughedButton";
            this.laughedButton.Size = new System.Drawing.Size(70, 36);
            this.laughedButton.TabIndex = 20;
            this.laughedButton.Text = "laughed at";
            this.laughedButton.UseVisualStyleBackColor = true;
            this.laughedButton.Click += new System.EventHandler(this.laughedButton_Click);
            // 
            // droveButton
            // 
            this.droveButton.Location = new System.Drawing.Point(428, 138);
            this.droveButton.Name = "droveButton";
            this.droveButton.Size = new System.Drawing.Size(63, 36);
            this.droveButton.TabIndex = 21;
            this.droveButton.Text = "drove";
            this.droveButton.UseVisualStyleBackColor = true;
            this.droveButton.Click += new System.EventHandler(this.droveButton_Click);
            // 
            // spaceButton
            // 
            this.spaceButton.Location = new System.Drawing.Point(226, 180);
            this.spaceButton.Name = "spaceButton";
            this.spaceButton.Size = new System.Drawing.Size(65, 36);
            this.spaceButton.TabIndex = 22;
            this.spaceButton.Text = "(&Space)";
            this.spaceButton.UseVisualStyleBackColor = true;
            this.spaceButton.Click += new System.EventHandler(this.spaceButton_Click);
            // 
            // periodButton
            // 
            this.periodButton.Location = new System.Drawing.Point(302, 180);
            this.periodButton.Name = "periodButton";
            this.periodButton.Size = new System.Drawing.Size(44, 36);
            this.periodButton.TabIndex = 23;
            this.periodButton.Text = ".";
            this.periodButton.UseVisualStyleBackColor = true;
            this.periodButton.Click += new System.EventHandler(this.periodButton_Click);
            // 
            // exclamationButton
            // 
            this.exclamationButton.Location = new System.Drawing.Point(358, 180);
            this.exclamationButton.Name = "exclamationButton";
            this.exclamationButton.Size = new System.Drawing.Size(44, 36);
            this.exclamationButton.TabIndex = 24;
            this.exclamationButton.Text = "!";
            this.exclamationButton.UseVisualStyleBackColor = true;
            this.exclamationButton.Click += new System.EventHandler(this.exclamationButton_Click);
            // 
            // clearButton
            // 
            this.clearButton.Location = new System.Drawing.Point(216, 319);
            this.clearButton.Name = "clearButton";
            this.clearButton.Size = new System.Drawing.Size(75, 33);
            this.clearButton.TabIndex = 25;
            this.clearButton.Text = "&Clear";
            this.clearButton.UseVisualStyleBackColor = true;
            this.clearButton.Click += new System.EventHandler(this.clearButton_Click);
            // 
            // exitButton
            // 
            this.exitButton.Location = new System.Drawing.Point(358, 319);
            this.exitButton.Name = "exitButton";
            this.exitButton.Size = new System.Drawing.Size(76, 33);
            this.exitButton.TabIndex = 26;
            this.exitButton.Text = "&Exit";
            this.exitButton.UseVisualStyleBackColor = true;
            this.exitButton.Click += new System.EventHandler(this.exitButton_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(633, 386);
            this.Controls.Add(this.exitButton);
            this.Controls.Add(this.clearButton);
            this.Controls.Add(this.exclamationButton);
            this.Controls.Add(this.periodButton);
            this.Controls.Add(this.spaceButton);
            this.Controls.Add(this.droveButton);
            this.Controls.Add(this.laughedButton);
            this.Controls.Add(this.spokeButton);
            this.Controls.Add(this.rodeButton);
            this.Controls.Add(this.lookedButton);
            this.Controls.Add(this.strangeButton);
            this.Controls.Add(this.smallButton);
            this.Controls.Add(this.bigButton);
            this.Controls.Add(this.beautifulButton);
            this.Controls.Add(this.bicycleButton);
            this.Controls.Add(this.carButton);
            this.Controls.Add(this.catButton);
            this.Controls.Add(this.dogButton);
            this.Controls.Add(this.womanButton);
            this.Controls.Add(this.sentenceLabel);
            this.Controls.Add(this.manButton);
            this.Controls.Add(this.lowercaseTheButton);
            this.Controls.Add(this.capitializedTheButton);
            this.Controls.Add(this.capitializedAnButton);
            this.Controls.Add(this.lowercaseAnButton);
            this.Controls.Add(this.lowerAButton);
            this.Controls.Add(this.uppercaseAButton);
            this.Name = "Form1";
            this.Text = "Sentence Builder";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button uppercaseAButton;
        private System.Windows.Forms.Button lowerAButton;
        private System.Windows.Forms.Button lowercaseAnButton;
        private System.Windows.Forms.Button capitializedAnButton;
        private System.Windows.Forms.Button capitializedTheButton;
        private System.Windows.Forms.Button lowercaseTheButton;
        private System.Windows.Forms.Button manButton;
        private System.Windows.Forms.Label sentenceLabel;
        private System.Windows.Forms.Button womanButton;
        private System.Windows.Forms.Button dogButton;
        private System.Windows.Forms.Button catButton;
        private System.Windows.Forms.Button carButton;
        private System.Windows.Forms.Button bicycleButton;
        private System.Windows.Forms.Button beautifulButton;
        private System.Windows.Forms.Button bigButton;
        private System.Windows.Forms.Button smallButton;
        private System.Windows.Forms.Button strangeButton;
        private System.Windows.Forms.Button lookedButton;
        private System.Windows.Forms.Button rodeButton;
        private System.Windows.Forms.Button spokeButton;
        private System.Windows.Forms.Button laughedButton;
        private System.Windows.Forms.Button droveButton;
        private System.Windows.Forms.Button spaceButton;
        private System.Windows.Forms.Button periodButton;
        private System.Windows.Forms.Button exclamationButton;
        private System.Windows.Forms.Button clearButton;
        private System.Windows.Forms.Button exitButton;
    }
}

