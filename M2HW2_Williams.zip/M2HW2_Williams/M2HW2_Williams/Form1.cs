﻿/**
* 02/18/18
* CSC 153
* Aaron Williams
* This program will allow the user to make a sentence out of pre-determined words
*/

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace M2HW2_Williams
{
    public partial class Form1 : Form
    {
        private string userSentence = "";
        public Form1()
        {
            InitializeComponent();
        }

        private void clearButton_Click(object sender, EventArgs e)
        {
            //Clears the label and variable holding the user's created sentence
            userSentence = "";
            sentenceLabel.Text = "";
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            //Exit program
            this.Close();
        }

        private void uppercaseAButton_Click(object sender, EventArgs e)
        {
            //Adds "A" to the user's sentence
            userSentence += "A";
            //Saves the button's input to the variable
            sentenceLabel.Text = userSentence;
        }

        private void lowerAButton_Click(object sender, EventArgs e)
        {
            //Adds "a" to the user's sentence
            userSentence += "a";
            sentenceLabel.Text = userSentence;
        }

        private void capitializedAnButton_Click(object sender, EventArgs e)
        {
            //Adds "An" to the user's sentence
            userSentence += "An";
            sentenceLabel.Text = userSentence;
        }

        private void lowercaseAnButton_Click(object sender, EventArgs e)
        {
            //Adds "an" to the user's sentence
            userSentence += "an";
            sentenceLabel.Text = userSentence;
        }

        private void capitializedTheButton_Click(object sender, EventArgs e)
        {
            //Adds "The" to the user's sentence
            userSentence += "The";
            sentenceLabel.Text = userSentence;
        }

        private void lowercaseTheButton_Click(object sender, EventArgs e)
        {
            //Adds "the" to the user's sentence
            userSentence += "the";
            sentenceLabel.Text = userSentence;
        }

        private void manButton_Click(object sender, EventArgs e)
        {
            //Adds "man" to the user's sentence
            userSentence += "man";
            sentenceLabel.Text = userSentence;
        }

        private void womanButton_Click(object sender, EventArgs e)
        {
            //Adds "woman" to the user's sentence
            userSentence += "woman";
            sentenceLabel.Text = userSentence;
        }

        private void dogButton_Click(object sender, EventArgs e)
        {
            //Adds "dog" to the user's sentence
            userSentence += "dog";
            sentenceLabel.Text = userSentence;
        }

        private void catButton_Click(object sender, EventArgs e)
        {
            //Adds "cat" to the user's sentence
            userSentence += "cat";
            sentenceLabel.Text = userSentence;
        }

        private void carButton_Click(object sender, EventArgs e)
        {
            //Adds "car" to the user's sentence
            userSentence += "car";
            sentenceLabel.Text = userSentence;
        }

        private void bicycleButton_Click(object sender, EventArgs e)
        {
            //Adds "bicycle" to the user's sentence
            userSentence += "bicycle";
            sentenceLabel.Text = userSentence;
        }

        private void beautifulButton_Click(object sender, EventArgs e)
        {
            //Adds "beautiful" to the user's sentence
            userSentence += "beautiful";
            sentenceLabel.Text = userSentence;
        }

        private void bigButton_Click(object sender, EventArgs e)
        {
            //Adds "big" to the user's sentence
            userSentence += "big";
            sentenceLabel.Text = userSentence;
        }

        private void smallButton_Click(object sender, EventArgs e)
        {
            //Adds "small" to the user's sentence
            userSentence += "small";
            sentenceLabel.Text = userSentence;
        }

        private void strangeButton_Click(object sender, EventArgs e)
        {
            //Adds "strange" to the user's sentence
            userSentence += "strange";
            sentenceLabel.Text = userSentence;
        }

        private void lookedButton_Click(object sender, EventArgs e)
        {
            //Adds "looked at" to the user's sentence
            userSentence += "looked at";
            sentenceLabel.Text = userSentence;
        }

        private void rodeButton_Click(object sender, EventArgs e)
        {
            //Adds "rode" to the user's sentence
            userSentence += "rode";
            sentenceLabel.Text = userSentence;
        }

        private void spokeButton_Click(object sender, EventArgs e)
        {
            //Adds "spoke to" to the user's sentence
            userSentence += "spoke to";
            sentenceLabel.Text = userSentence;
        }

        private void laughedButton_Click(object sender, EventArgs e)
        {
            //Adds "laughed at" to the user's sentence
            userSentence += "laughed at";
            sentenceLabel.Text = userSentence;
        }

        private void droveButton_Click(object sender, EventArgs e)
        {
            //Adds "drove" to the user's sentence
            userSentence += "drove";
            sentenceLabel.Text = userSentence;
        }

        private void spaceButton_Click(object sender, EventArgs e)
        {
            //Adds " " to the user's sentence
            userSentence += " ";
            sentenceLabel.Text = userSentence;
        }

        private void periodButton_Click(object sender, EventArgs e)
        {
            //Adds "." to the user's sentence
            userSentence += ".";
            sentenceLabel.Text = userSentence;
        }

        private void exclamationButton_Click(object sender, EventArgs e)
        {
            //Adds "!" to the user's sentence
            userSentence += "!";
            sentenceLabel.Text = userSentence;
        }
    }
}
