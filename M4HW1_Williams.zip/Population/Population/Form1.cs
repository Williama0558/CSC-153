﻿/**
* 03/25/2018
* CSC 153
* Aaron Williams
* This program will calculate the growth of organisms over a period of days
*/

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Population
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void calculateButton_Click(object sender, EventArgs e)
        {
            try
            {
                // Variables
                int startingOrganisms;
                double dailyIncrease;
                int numberOfDays;
                int dayCounter = 1;
                double newOrganisms = 0;
                double percentIncrease = 0;
                double organismIncrease = 0;



                // Get the number of starting organisms.
                if (int.TryParse(organismsTextBox.Text, out startingOrganisms))
                {
                    // Get the average daily increase.
                    if (double.TryParse(dailyIncreaseTextBox.Text, out dailyIncrease))
                    {
                        // Get the number of days.
                        if (int.TryParse(daysTextBox.Text, out numberOfDays))
                        {
                            // If-else statement for if the user only enters in one for days.
                            if (numberOfDays == 1)
                            {
                                // Adds the first result to the list box
                                resultsListBox.Items.Add(dayCounter + "\t\t" + startingOrganisms);
                            }
                            else
                            {
                                // Adds the first result to the list box
                                resultsListBox.Items.Add(dayCounter + "\t\t" + startingOrganisms);
                                // Gets the percent increase of organisms
                                percentIncrease = dailyIncrease * .01;
                                // Calculates how many new organisms are made
                                newOrganisms = startingOrganisms * percentIncrease;
                                // Adds the new organisms to the original to get the total
                                newOrganisms = newOrganisms + startingOrganisms;
                                // Increments the day counter by one
                                dayCounter += 1;
                                // Addds the result to the list box
                                resultsListBox.Items.Add(dayCounter + "\t\t" + newOrganisms);
                                // While loop that will run until it reaches the number of days that the user entered.
                                while (dayCounter < numberOfDays)
                                {
                                    // Finds out how many new organisms are made each day
                                    organismIncrease = newOrganisms * percentIncrease;
                                    // Adds the new organisms to the total
                                    newOrganisms = newOrganisms + organismIncrease;
                                    // Increments day counter by one
                                    dayCounter += 1;
                                    // Adds results to the listbox
                                    resultsListBox.Items.Add(dayCounter + "\t\t" + newOrganisms);
                                }
                            }
                        }
                        else
                        {
                            // Invalid number of days entered.
                            MessageBox.Show("Invalid value entered for number of days.");
                        }
                    }
                    else
                    {
                        // Invalid daily increase entered
                        MessageBox.Show("Invalid value entered for daily increase.");
                    }
                }
                else
                {
                    // Invalid starting organisms entered.
                    MessageBox.Show("Invalid value entered for starting organisms.");
                }
            }

            catch (Exception ex)
            {
                // Shows an error message
                MessageBox.Show(ex.Message);
            }
        }


        private void Form1_Load(object sender, EventArgs e)
        {
            resultsListBox.Items.Add("Day\t\tApproximate Population");
        }

        private void clearButton_Click(object sender, EventArgs e)
        {
            // Clears all information and results from the boxes
            organismsTextBox.Text = "";
            dailyIncreaseTextBox.Text = "";
            daysTextBox.Text = "";
            resultsListBox.Items.Clear();
            // Makes it so this information never leaves the listbox
            resultsListBox.Items.Add("Day\t\tApproximate Population");
            // Resets focus back to the organism textbox
            organismsTextBox.Focus();
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            // Closes program
            this.Close();
        }
    }
}
