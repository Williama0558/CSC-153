﻿/**
* 03/25/2018
* CSC 153
* Aaron Williams
* This program will simulate rolling a pair of dice using random numbers
*/

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Dice_Simulator
{
    public partial class Form1 : Form
    {

        public Form1()
        {
            InitializeComponent();
        }

        private void rollButton_Click(object sender, EventArgs e)
        {
            try
            {
                // Variable to show which face of the die is displayed
                int dieOneFace;
                int dieTwoFace;

                // Create a Random object.
                Random rand = new Random();

                // Get a random integer in the range of 0 to 5
                // One number for each side of the die
                dieOneFace = rand.Next(6);
                dieTwoFace = rand.Next(6);

                // Changes the image displayed based on the random number generated
                switch(dieOneFace)
                {
                    case 0:
                        // Loads an image from the program's directory to store in the pictureBox
                        this.firstDiePictureBox.Image = Image.FromFile(Application.StartupPath + "\\" + "Die1.bmp");
                        // Ends the case
                        break;

                    case 1:
                        this.firstDiePictureBox.Image = Image.FromFile(Application.StartupPath + "\\" + "Die2.bmp");
                        break;

                    case 2:
                        this.firstDiePictureBox.Image = Image.FromFile(Application.StartupPath + "\\" + "Die3.bmp");
                        break;

                    case 3:
                        this.firstDiePictureBox.Image = Image.FromFile(Application.StartupPath + "\\" + "Die4.bmp");
                        break;

                    case 4:
                        this.firstDiePictureBox.Image = Image.FromFile(Application.StartupPath + "\\" + "Die5.bmp");
                        break;

                    case 5:
                        this.firstDiePictureBox.Image = Image.FromFile(Application.StartupPath + "\\" + "Die6.bmp");
                        break;

                }
                switch(dieTwoFace)
                {
                    case 0:

                        this.secondDiePictureBox.Image = Image.FromFile(Application.StartupPath + "\\" + "Die1.bmp");
                        break;

                    case 1:
                        this.secondDiePictureBox.Image = Image.FromFile(Application.StartupPath + "\\" + "Die2.bmp");
                        break;

                    case 2:
                        this.secondDiePictureBox.Image = Image.FromFile(Application.StartupPath + "\\" + "Die3.bmp");
                        break;

                    case 3:
                        this.secondDiePictureBox.Image = Image.FromFile(Application.StartupPath + "\\" + "Die4.bmp");
                        break;

                    case 4:
                        this.secondDiePictureBox.Image = Image.FromFile(Application.StartupPath + "\\" + "Die5.bmp");
                        break;

                    case 5:
                        this.secondDiePictureBox.Image = Image.FromFile(Application.StartupPath + "\\" + "Die6.bmp");
                        break;
                }
            }


            catch (Exception ex)
            {
                // Shows an error message
                MessageBox.Show(ex.Message);
            }
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            // Closes program
            this.Close();
        }
    }
}
