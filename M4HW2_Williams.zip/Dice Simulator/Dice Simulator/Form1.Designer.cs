﻿namespace Dice_Simulator
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.firstDiePictureBox = new System.Windows.Forms.PictureBox();
            this.rollButton = new System.Windows.Forms.Button();
            this.exitButton = new System.Windows.Forms.Button();
            this.secondDiePictureBox = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.firstDiePictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.secondDiePictureBox)).BeginInit();
            this.SuspendLayout();
            // 
            // firstDiePictureBox
            // 
            this.firstDiePictureBox.Image = ((System.Drawing.Image)(resources.GetObject("firstDiePictureBox.Image")));
            this.firstDiePictureBox.Location = new System.Drawing.Point(12, 21);
            this.firstDiePictureBox.Name = "firstDiePictureBox";
            this.firstDiePictureBox.Size = new System.Drawing.Size(105, 107);
            this.firstDiePictureBox.TabIndex = 0;
            this.firstDiePictureBox.TabStop = false;
            // 
            // rollButton
            // 
            this.rollButton.Location = new System.Drawing.Point(61, 161);
            this.rollButton.Name = "rollButton";
            this.rollButton.Size = new System.Drawing.Size(75, 33);
            this.rollButton.TabIndex = 1;
            this.rollButton.Text = "Roll Dice";
            this.rollButton.UseVisualStyleBackColor = true;
            this.rollButton.Click += new System.EventHandler(this.rollButton_Click);
            // 
            // exitButton
            // 
            this.exitButton.Location = new System.Drawing.Point(153, 161);
            this.exitButton.Name = "exitButton";
            this.exitButton.Size = new System.Drawing.Size(75, 33);
            this.exitButton.TabIndex = 2;
            this.exitButton.Text = "Exit";
            this.exitButton.UseVisualStyleBackColor = true;
            this.exitButton.Click += new System.EventHandler(this.exitButton_Click);
            // 
            // secondDiePictureBox
            // 
            this.secondDiePictureBox.Image = ((System.Drawing.Image)(resources.GetObject("secondDiePictureBox.Image")));
            this.secondDiePictureBox.Location = new System.Drawing.Point(153, 21);
            this.secondDiePictureBox.Name = "secondDiePictureBox";
            this.secondDiePictureBox.Size = new System.Drawing.Size(105, 106);
            this.secondDiePictureBox.TabIndex = 3;
            this.secondDiePictureBox.TabStop = false;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(276, 211);
            this.Controls.Add(this.secondDiePictureBox);
            this.Controls.Add(this.exitButton);
            this.Controls.Add(this.rollButton);
            this.Controls.Add(this.firstDiePictureBox);
            this.Name = "Form1";
            this.Text = "Dice Simulator";
            ((System.ComponentModel.ISupportInitialize)(this.firstDiePictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.secondDiePictureBox)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.PictureBox firstDiePictureBox;
        private System.Windows.Forms.Button rollButton;
        private System.Windows.Forms.Button exitButton;
        private System.Windows.Forms.PictureBox secondDiePictureBox;
    }
}

