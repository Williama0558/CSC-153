﻿/**
* 05/13/18
* CSC 153
* Aaron Williams
* This program will let the user store and display information about a pet
*/

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using PetClassLibrary;

namespace PetClass
{
    public partial class Form1 : Form
    {
        // Creates a list to store the information of pets that the user enters in
        List<Pet> petList = new List<Pet>();
        public Form1()
        {
            InitializeComponent();
        }
        private void getPetInfo(Pet pet)
        {
            // Sends the information the user enters in to the Pet class
            pet.Name = nameTextBox.Text;
            pet.Type = typeTextBox.Text;
            pet.Age = ageTextBox.Text;
        }

        private void addButton_Click(object sender, EventArgs e)
        {
            // Creates a new instance of the Pet class
            Pet newPet = new Pet();
            getPetInfo(newPet);
            // Adds the new instance of the Pet class to the list object
            petList.Add(newPet);
            // Adds the pet information to the list box
            petListBox.Items.Add(newPet.Name + "\t\t" + newPet.Type + "\t\t" + newPet.Age);
            // Resets the text boxes for the user
            nameTextBox.Text = "";
            typeTextBox.Text = "";
            ageTextBox.Text = "";
            nameTextBox.Focus();
        }

        private void clearTextButton_Click(object sender, EventArgs e)
        {
            // Clears the text boxes and resets focus back to nameTextBox
            nameTextBox.Text = "";
            typeTextBox.Text = "";
            ageTextBox.Text = "";
            nameTextBox.Focus();
        }

        private void clearListButton_Click(object sender, EventArgs e)
        {
            // Clears the list box
            petListBox.Items.Clear();
            // Readds the column names so they don't get deleted
            petListBox.Items.Add("Name\t\tType\t\tAge");
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            // Closes the program
            this.Close();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            // Creates the names of the columns in the list box when the form first loads
            petListBox.Items.Add("Name\t\tType\t\tAge");
        }
    }

}
