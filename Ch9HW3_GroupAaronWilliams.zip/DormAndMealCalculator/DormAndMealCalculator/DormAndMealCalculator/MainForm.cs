﻿/**
* 05/13/18
* CSC 153
* Aaron Williams
* This program will calculate the costs of different meal plan and dorm combos
*/

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DormAndMealCalculator
{
    public partial class MainForm : Form
    {
        public MainForm()
        {
            InitializeComponent();
        }

        private void calculateButton_Click(object sender, EventArgs e)
        {
            // Variables
            decimal dormChoiceCost = 0m;
            decimal mealPlanCost = 0m;
            decimal totalCost = 0m;
            const decimal ALLEN_HALL_COST = 1500m;
            const decimal PIKE_HALL_COST = 1600m;
            const decimal FARTHING_HALL_COST = 1800m;
            const decimal SUITES_COST = 2500m;
            const decimal SEVEN_MEALS_COST = 600m;
            const decimal FOURTEEN_MEALS_COST = 1200m;
            const decimal UNLIMITED_MEALS_COST = 1700m;

            // Create an instance of the ChargesForm
            ChargesForm chargeForm = new ChargesForm();

            // If-else statement that stores the cost of the selected dorm in a variable
            // to add it to the total cost
            if (allenRadioButton.Checked == true)
            {
                dormChoiceCost =+ ALLEN_HALL_COST;
            }
            else if(pikeRadioButton.Checked == true)
            {
                dormChoiceCost =+ PIKE_HALL_COST;
            }
            else if(farthingRadioButton.Checked == true)
            {
                dormChoiceCost =+ FARTHING_HALL_COST;
            }
            else if(suitesRadioButton.Checked == true)
            {
                dormChoiceCost =+ SUITES_COST;
            }

            // If-else statement that stores the cost of the selected meal plan in a variable
            // to later add it to the total cost
            if(sevenMealsRadioButton.Checked == true)
            {
                mealPlanCost =+ SEVEN_MEALS_COST;
            }
            else if(fourteenMealsRadioButton.Checked == true)
            {
                mealPlanCost =+ FOURTEEN_MEALS_COST;
            }
            else if(unlimitedRadioButton.Checked == true)
            {
                mealPlanCost =+ UNLIMITED_MEALS_COST;
            }

            // Get the total cost of the student's plan
            totalCost =+ dormChoiceCost + mealPlanCost;

            // Send the total cost to a label on the second form
            chargeForm.costLabel.Text = "$" + totalCost.ToString();

            //Display the Charges Form
            chargeForm.ShowDialog();
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            // Closes the program
            this.Close();
        }
    }
}
