﻿namespace DormAndMealCalculator
{
    partial class MainForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dormGroupBox = new System.Windows.Forms.GroupBox();
            this.mealPlanGroupBox = new System.Windows.Forms.GroupBox();
            this.calculateButton = new System.Windows.Forms.Button();
            this.exitButton = new System.Windows.Forms.Button();
            this.sevenMealsRadioButton = new System.Windows.Forms.RadioButton();
            this.fourteenMealsRadioButton = new System.Windows.Forms.RadioButton();
            this.unlimitedRadioButton = new System.Windows.Forms.RadioButton();
            this.allenRadioButton = new System.Windows.Forms.RadioButton();
            this.pikeRadioButton = new System.Windows.Forms.RadioButton();
            this.farthingRadioButton = new System.Windows.Forms.RadioButton();
            this.suitesRadioButton = new System.Windows.Forms.RadioButton();
            this.dormGroupBox.SuspendLayout();
            this.mealPlanGroupBox.SuspendLayout();
            this.SuspendLayout();
            // 
            // dormGroupBox
            // 
            this.dormGroupBox.Controls.Add(this.suitesRadioButton);
            this.dormGroupBox.Controls.Add(this.farthingRadioButton);
            this.dormGroupBox.Controls.Add(this.pikeRadioButton);
            this.dormGroupBox.Controls.Add(this.allenRadioButton);
            this.dormGroupBox.Location = new System.Drawing.Point(13, 13);
            this.dormGroupBox.Name = "dormGroupBox";
            this.dormGroupBox.Size = new System.Drawing.Size(183, 122);
            this.dormGroupBox.TabIndex = 0;
            this.dormGroupBox.TabStop = false;
            this.dormGroupBox.Text = "Dormitories";
            // 
            // mealPlanGroupBox
            // 
            this.mealPlanGroupBox.Controls.Add(this.unlimitedRadioButton);
            this.mealPlanGroupBox.Controls.Add(this.fourteenMealsRadioButton);
            this.mealPlanGroupBox.Controls.Add(this.sevenMealsRadioButton);
            this.mealPlanGroupBox.Location = new System.Drawing.Point(202, 20);
            this.mealPlanGroupBox.Name = "mealPlanGroupBox";
            this.mealPlanGroupBox.Size = new System.Drawing.Size(173, 100);
            this.mealPlanGroupBox.TabIndex = 1;
            this.mealPlanGroupBox.TabStop = false;
            this.mealPlanGroupBox.Text = "Meal Plans";
            // 
            // calculateButton
            // 
            this.calculateButton.Location = new System.Drawing.Point(84, 152);
            this.calculateButton.Name = "calculateButton";
            this.calculateButton.Size = new System.Drawing.Size(75, 41);
            this.calculateButton.TabIndex = 2;
            this.calculateButton.Text = "&Calculate Costs";
            this.calculateButton.UseVisualStyleBackColor = true;
            this.calculateButton.Click += new System.EventHandler(this.calculateButton_Click);
            // 
            // exitButton
            // 
            this.exitButton.Location = new System.Drawing.Point(209, 152);
            this.exitButton.Name = "exitButton";
            this.exitButton.Size = new System.Drawing.Size(75, 41);
            this.exitButton.TabIndex = 3;
            this.exitButton.Text = "&Exit";
            this.exitButton.UseVisualStyleBackColor = true;
            this.exitButton.Click += new System.EventHandler(this.exitButton_Click);
            // 
            // sevenMealsRadioButton
            // 
            this.sevenMealsRadioButton.AutoSize = true;
            this.sevenMealsRadioButton.Checked = true;
            this.sevenMealsRadioButton.Location = new System.Drawing.Point(7, 20);
            this.sevenMealsRadioButton.Name = "sevenMealsRadioButton";
            this.sevenMealsRadioButton.Size = new System.Drawing.Size(142, 17);
            this.sevenMealsRadioButton.TabIndex = 0;
            this.sevenMealsRadioButton.TabStop = true;
            this.sevenMealsRadioButton.Text = "7 Meals per Week($600)";
            this.sevenMealsRadioButton.UseVisualStyleBackColor = true;
            // 
            // fourteenMealsRadioButton
            // 
            this.fourteenMealsRadioButton.AutoSize = true;
            this.fourteenMealsRadioButton.Location = new System.Drawing.Point(7, 44);
            this.fourteenMealsRadioButton.Name = "fourteenMealsRadioButton";
            this.fourteenMealsRadioButton.Size = new System.Drawing.Size(154, 17);
            this.fourteenMealsRadioButton.TabIndex = 1;
            this.fourteenMealsRadioButton.TabStop = true;
            this.fourteenMealsRadioButton.Text = "14 Meals per Week($1200)";
            this.fourteenMealsRadioButton.UseVisualStyleBackColor = true;
            // 
            // unlimitedRadioButton
            // 
            this.unlimitedRadioButton.AutoSize = true;
            this.unlimitedRadioButton.Location = new System.Drawing.Point(7, 68);
            this.unlimitedRadioButton.Name = "unlimitedRadioButton";
            this.unlimitedRadioButton.Size = new System.Drawing.Size(135, 17);
            this.unlimitedRadioButton.TabIndex = 2;
            this.unlimitedRadioButton.TabStop = true;
            this.unlimitedRadioButton.Text = "Unlimited Meals($1700)";
            this.unlimitedRadioButton.UseVisualStyleBackColor = true;
            // 
            // allenRadioButton
            // 
            this.allenRadioButton.AutoSize = true;
            this.allenRadioButton.Location = new System.Drawing.Point(7, 20);
            this.allenRadioButton.Name = "allenRadioButton";
            this.allenRadioButton.Size = new System.Drawing.Size(105, 17);
            this.allenRadioButton.TabIndex = 0;
            this.allenRadioButton.TabStop = true;
            this.allenRadioButton.Text = "Allen Hall($1500)";
            this.allenRadioButton.UseVisualStyleBackColor = true;
            // 
            // pikeRadioButton
            // 
            this.pikeRadioButton.AutoSize = true;
            this.pikeRadioButton.Location = new System.Drawing.Point(7, 44);
            this.pikeRadioButton.Name = "pikeRadioButton";
            this.pikeRadioButton.Size = new System.Drawing.Size(103, 17);
            this.pikeRadioButton.TabIndex = 1;
            this.pikeRadioButton.TabStop = true;
            this.pikeRadioButton.Text = "Pike Hall($1600)";
            this.pikeRadioButton.UseVisualStyleBackColor = true;
            // 
            // farthingRadioButton
            // 
            this.farthingRadioButton.AutoSize = true;
            this.farthingRadioButton.Location = new System.Drawing.Point(7, 68);
            this.farthingRadioButton.Name = "farthingRadioButton";
            this.farthingRadioButton.Size = new System.Drawing.Size(120, 17);
            this.farthingRadioButton.TabIndex = 2;
            this.farthingRadioButton.TabStop = true;
            this.farthingRadioButton.Text = "Farthing Hall($1800)";
            this.farthingRadioButton.UseVisualStyleBackColor = true;
            // 
            // suitesRadioButton
            // 
            this.suitesRadioButton.AutoSize = true;
            this.suitesRadioButton.Location = new System.Drawing.Point(7, 92);
            this.suitesRadioButton.Name = "suitesRadioButton";
            this.suitesRadioButton.Size = new System.Drawing.Size(139, 17);
            this.suitesRadioButton.TabIndex = 3;
            this.suitesRadioButton.TabStop = true;
            this.suitesRadioButton.Text = "University Suites($2500)";
            this.suitesRadioButton.UseVisualStyleBackColor = true;
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(382, 205);
            this.Controls.Add(this.exitButton);
            this.Controls.Add(this.calculateButton);
            this.Controls.Add(this.mealPlanGroupBox);
            this.Controls.Add(this.dormGroupBox);
            this.Name = "MainForm";
            this.Text = "Dorm and Meal Plan Calculator";
            this.dormGroupBox.ResumeLayout(false);
            this.dormGroupBox.PerformLayout();
            this.mealPlanGroupBox.ResumeLayout(false);
            this.mealPlanGroupBox.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox dormGroupBox;
        private System.Windows.Forms.GroupBox mealPlanGroupBox;
        private System.Windows.Forms.Button calculateButton;
        private System.Windows.Forms.Button exitButton;
        private System.Windows.Forms.RadioButton unlimitedRadioButton;
        private System.Windows.Forms.RadioButton fourteenMealsRadioButton;
        private System.Windows.Forms.RadioButton sevenMealsRadioButton;
        private System.Windows.Forms.RadioButton suitesRadioButton;
        private System.Windows.Forms.RadioButton farthingRadioButton;
        private System.Windows.Forms.RadioButton pikeRadioButton;
        private System.Windows.Forms.RadioButton allenRadioButton;
    }
}

