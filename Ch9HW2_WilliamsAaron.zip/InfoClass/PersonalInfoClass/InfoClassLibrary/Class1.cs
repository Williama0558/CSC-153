﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InfoClassLibrary
{
    public class Person
    {
        // Fields
        private string _name;
        private string _address;
        private string _age;
        private string _phoneNumber;

        // Constructor
        public Person()
        {
            _name = "";
            _address = "";
            _age = "";
            _phoneNumber = "";
        }

        // Name property
        public string Name
        {
            get { return _name; }
            set { _name = value; }
        }

        // Address property
        public string Address
        {
            get { return _address; }
            set { _address = value; }
        }

        // Age property
        public string Age
        {
            get { return _age; }
            set { _age = value; }
        }

        // Phone number property
        public string Phone_Number
        {
            get { return _phoneNumber; }
            set { _phoneNumber = value; }
        }

    }
}
