﻿namespace PersonalInfoClass
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.exitButton = new System.Windows.Forms.Button();
            this.displayButton = new System.Windows.Forms.Button();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.person3PhoneLabel = new System.Windows.Forms.Label();
            this.person3NameLabel = new System.Windows.Forms.Label();
            this.person3AgeLabel = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.person3AddressLabel = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.person2PhoneLabel = new System.Windows.Forms.Label();
            this.person2NameLabel = new System.Windows.Forms.Label();
            this.person2AgeLabel = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.person2AddressLabel = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.person1PhoneLabel = new System.Windows.Forms.Label();
            this.person1AgeLabel = new System.Windows.Forms.Label();
            this.person1AddressLabel = new System.Windows.Forms.Label();
            this.person1NameLabel = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.groupBox3.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // exitButton
            // 
            this.exitButton.Location = new System.Drawing.Point(429, 177);
            this.exitButton.Name = "exitButton";
            this.exitButton.Size = new System.Drawing.Size(75, 29);
            this.exitButton.TabIndex = 20;
            this.exitButton.Text = "Exit";
            this.exitButton.UseVisualStyleBackColor = true;
            this.exitButton.Click += new System.EventHandler(this.exitButton_Click);
            // 
            // displayButton
            // 
            this.displayButton.Location = new System.Drawing.Point(197, 177);
            this.displayButton.Name = "displayButton";
            this.displayButton.Size = new System.Drawing.Size(75, 29);
            this.displayButton.TabIndex = 19;
            this.displayButton.Text = "Display Info";
            this.displayButton.UseVisualStyleBackColor = true;
            this.displayButton.Click += new System.EventHandler(this.displayButton_Click);
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.person3PhoneLabel);
            this.groupBox3.Controls.Add(this.person3NameLabel);
            this.groupBox3.Controls.Add(this.person3AgeLabel);
            this.groupBox3.Controls.Add(this.label20);
            this.groupBox3.Controls.Add(this.person3AddressLabel);
            this.groupBox3.Controls.Add(this.label19);
            this.groupBox3.Controls.Add(this.label18);
            this.groupBox3.Controls.Add(this.label17);
            this.groupBox3.Location = new System.Drawing.Point(462, 12);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(219, 146);
            this.groupBox3.TabIndex = 18;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Person 3";
            // 
            // person3PhoneLabel
            // 
            this.person3PhoneLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.person3PhoneLabel.Location = new System.Drawing.Point(96, 114);
            this.person3PhoneLabel.Name = "person3PhoneLabel";
            this.person3PhoneLabel.Size = new System.Drawing.Size(100, 23);
            this.person3PhoneLabel.TabIndex = 23;
            // 
            // person3NameLabel
            // 
            this.person3NameLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.person3NameLabel.Location = new System.Drawing.Point(96, 31);
            this.person3NameLabel.Name = "person3NameLabel";
            this.person3NameLabel.Size = new System.Drawing.Size(100, 23);
            this.person3NameLabel.TabIndex = 20;
            // 
            // person3AgeLabel
            // 
            this.person3AgeLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.person3AgeLabel.Location = new System.Drawing.Point(96, 87);
            this.person3AgeLabel.Name = "person3AgeLabel";
            this.person3AgeLabel.Size = new System.Drawing.Size(100, 23);
            this.person3AgeLabel.TabIndex = 22;
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(51, 32);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(38, 13);
            this.label20.TabIndex = 16;
            this.label20.Text = "Name:";
            // 
            // person3AddressLabel
            // 
            this.person3AddressLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.person3AddressLabel.Location = new System.Drawing.Point(96, 59);
            this.person3AddressLabel.Name = "person3AddressLabel";
            this.person3AddressLabel.Size = new System.Drawing.Size(100, 23);
            this.person3AddressLabel.TabIndex = 21;
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(41, 59);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(48, 13);
            this.label19.TabIndex = 17;
            this.label19.Text = "Address:";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(61, 87);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(29, 13);
            this.label18.TabIndex = 18;
            this.label18.Text = "Age:";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(9, 114);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(81, 13);
            this.label17.TabIndex = 19;
            this.label17.Text = "Phone Number:";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.person2PhoneLabel);
            this.groupBox2.Controls.Add(this.person2NameLabel);
            this.groupBox2.Controls.Add(this.person2AgeLabel);
            this.groupBox2.Controls.Add(this.label12);
            this.groupBox2.Controls.Add(this.person2AddressLabel);
            this.groupBox2.Controls.Add(this.label11);
            this.groupBox2.Controls.Add(this.label10);
            this.groupBox2.Controls.Add(this.label9);
            this.groupBox2.Location = new System.Drawing.Point(237, 12);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(219, 146);
            this.groupBox2.TabIndex = 17;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Person 2";
            // 
            // person2PhoneLabel
            // 
            this.person2PhoneLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.person2PhoneLabel.Location = new System.Drawing.Point(95, 114);
            this.person2PhoneLabel.Name = "person2PhoneLabel";
            this.person2PhoneLabel.Size = new System.Drawing.Size(100, 23);
            this.person2PhoneLabel.TabIndex = 15;
            // 
            // person2NameLabel
            // 
            this.person2NameLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.person2NameLabel.Location = new System.Drawing.Point(95, 31);
            this.person2NameLabel.Name = "person2NameLabel";
            this.person2NameLabel.Size = new System.Drawing.Size(100, 23);
            this.person2NameLabel.TabIndex = 12;
            // 
            // person2AgeLabel
            // 
            this.person2AgeLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.person2AgeLabel.Location = new System.Drawing.Point(95, 87);
            this.person2AgeLabel.Name = "person2AgeLabel";
            this.person2AgeLabel.Size = new System.Drawing.Size(100, 23);
            this.person2AgeLabel.TabIndex = 14;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(50, 32);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(38, 13);
            this.label12.TabIndex = 8;
            this.label12.Text = "Name:";
            // 
            // person2AddressLabel
            // 
            this.person2AddressLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.person2AddressLabel.Location = new System.Drawing.Point(95, 59);
            this.person2AddressLabel.Name = "person2AddressLabel";
            this.person2AddressLabel.Size = new System.Drawing.Size(100, 23);
            this.person2AddressLabel.TabIndex = 13;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(40, 59);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(48, 13);
            this.label11.TabIndex = 9;
            this.label11.Text = "Address:";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(60, 87);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(29, 13);
            this.label10.TabIndex = 10;
            this.label10.Text = "Age:";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(8, 114);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(81, 13);
            this.label9.TabIndex = 11;
            this.label9.Text = "Phone Number:";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.person1PhoneLabel);
            this.groupBox1.Controls.Add(this.person1AgeLabel);
            this.groupBox1.Controls.Add(this.person1AddressLabel);
            this.groupBox1.Controls.Add(this.person1NameLabel);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Location = new System.Drawing.Point(12, 12);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(219, 146);
            this.groupBox1.TabIndex = 16;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Person 1";
            // 
            // person1PhoneLabel
            // 
            this.person1PhoneLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.person1PhoneLabel.Location = new System.Drawing.Point(88, 114);
            this.person1PhoneLabel.Name = "person1PhoneLabel";
            this.person1PhoneLabel.Size = new System.Drawing.Size(100, 23);
            this.person1PhoneLabel.TabIndex = 7;
            // 
            // person1AgeLabel
            // 
            this.person1AgeLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.person1AgeLabel.Location = new System.Drawing.Point(88, 87);
            this.person1AgeLabel.Name = "person1AgeLabel";
            this.person1AgeLabel.Size = new System.Drawing.Size(100, 23);
            this.person1AgeLabel.TabIndex = 6;
            // 
            // person1AddressLabel
            // 
            this.person1AddressLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.person1AddressLabel.Location = new System.Drawing.Point(88, 59);
            this.person1AddressLabel.Name = "person1AddressLabel";
            this.person1AddressLabel.Size = new System.Drawing.Size(100, 23);
            this.person1AddressLabel.TabIndex = 5;
            // 
            // person1NameLabel
            // 
            this.person1NameLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.person1NameLabel.Location = new System.Drawing.Point(88, 31);
            this.person1NameLabel.Name = "person1NameLabel";
            this.person1NameLabel.Size = new System.Drawing.Size(100, 23);
            this.person1NameLabel.TabIndex = 4;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(1, 114);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(81, 13);
            this.label4.TabIndex = 3;
            this.label4.Text = "Phone Number:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(53, 87);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(29, 13);
            this.label3.TabIndex = 2;
            this.label3.Text = "Age:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(33, 59);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(48, 13);
            this.label2.TabIndex = 1;
            this.label2.Text = "Address:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(43, 32);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(38, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Name:";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(695, 226);
            this.Controls.Add(this.exitButton);
            this.Controls.Add(this.displayButton);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Name = "Form1";
            this.Text = "Personal Info";
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button exitButton;
        private System.Windows.Forms.Button displayButton;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.Label person3PhoneLabel;
        private System.Windows.Forms.Label person3NameLabel;
        private System.Windows.Forms.Label person3AgeLabel;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label person3AddressLabel;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Label person2PhoneLabel;
        private System.Windows.Forms.Label person2NameLabel;
        private System.Windows.Forms.Label person2AgeLabel;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label person2AddressLabel;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label person1PhoneLabel;
        private System.Windows.Forms.Label person1AgeLabel;
        private System.Windows.Forms.Label person1AddressLabel;
        private System.Windows.Forms.Label person1NameLabel;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
    }
}

