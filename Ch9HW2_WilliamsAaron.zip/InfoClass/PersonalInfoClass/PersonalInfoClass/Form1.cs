﻿/**
* 05/13/18
* CSC 153
* Aaron Williams
* This program will let the user display the info of three people
*/

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using InfoClassLibrary;

namespace PersonalInfoClass
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void getPerson1Info(Person person1)
        {
            // Sets the information of the person in the Person Class
            person1.Name = "Aaron Williams";
            person1.Address = "4142 Sids Way";
            person1.Age = "21";
            person1.Phone_Number = "555-435-1231";
        }


        private void getPerson2Info(Person person2)
        {
            // Sets the information of the person in the Person Class
            person2.Name = "Brad Williams";
            person2.Address = "4142 Sids Way";
            person2.Age = "23";
            person2.Phone_Number = "555-435-5346";
        }


        private void getPerson3Info(Person person1)
        {
            // Sets the information of the person in the Person Class
            person1.Name = "Cameron Williams";
            person1.Address = "4142 Sids Way";
            person1.Age = "14";
            person1.Phone_Number = "555-435-6436";
        }


        private void displayButton_Click(object sender, EventArgs e)
        {
            // Create an object of the Person class to store the information of the first person
            Person person1 = new Person();
            // Get the information of the person
            getPerson1Info(person1);
            // Display the info of the person
            person1NameLabel.Text = person1.Name;
            person1AddressLabel.Text = person1.Address;
            person1AgeLabel.Text = person1.Age;
            person1PhoneLabel.Text = person1.Phone_Number;

            // Create an object of the Person class to store the information of the second person
            Person person2 = new Person();
            // Get the information of the person
            getPerson2Info(person2);
            // Display the info of the person
            person2NameLabel.Text = person2.Name;
            person2AddressLabel.Text = person2.Address;
            person2AgeLabel.Text = person2.Age;
            person2PhoneLabel.Text = person2.Phone_Number;

            // Create an object of the Person class to store the information of the third person
            Person person3 = new Person();
            // Get the information of the person
            getPerson3Info(person3);
            // Display the info of the person
            person3NameLabel.Text = person3.Name;
            person3AddressLabel.Text = person3.Address;
            person3AgeLabel.Text = person3.Age;
            person3PhoneLabel.Text = person3.Phone_Number;
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            // Close the program
            this.Close();
        }
    }
}
