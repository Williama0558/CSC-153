﻿namespace EmployeeClass
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.exitButton = new System.Windows.Forms.Button();
            this.displayButton = new System.Windows.Forms.Button();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.emp3PositionLabel = new System.Windows.Forms.Label();
            this.emp3DepartmentLabel = new System.Windows.Forms.Label();
            this.emp3IDLabel = new System.Windows.Forms.Label();
            this.emp3NameLabel = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.emp2PositionLabel = new System.Windows.Forms.Label();
            this.emp2DepartmentLabel = new System.Windows.Forms.Label();
            this.emp2IDLabel = new System.Windows.Forms.Label();
            this.emp2NameLabel = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.emp1PositionLabel = new System.Windows.Forms.Label();
            this.emp1DepartmentLabel = new System.Windows.Forms.Label();
            this.emp1IDLabel = new System.Windows.Forms.Label();
            this.emp1NameLabel = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.groupBox3.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // exitButton
            // 
            this.exitButton.Location = new System.Drawing.Point(429, 177);
            this.exitButton.Name = "exitButton";
            this.exitButton.Size = new System.Drawing.Size(75, 29);
            this.exitButton.TabIndex = 15;
            this.exitButton.Text = "Exit";
            this.exitButton.UseVisualStyleBackColor = true;
            this.exitButton.Click += new System.EventHandler(this.exitButton_Click);
            // 
            // displayButton
            // 
            this.displayButton.Location = new System.Drawing.Point(197, 177);
            this.displayButton.Name = "displayButton";
            this.displayButton.Size = new System.Drawing.Size(75, 29);
            this.displayButton.TabIndex = 14;
            this.displayButton.Text = "Display Info";
            this.displayButton.UseVisualStyleBackColor = true;
            this.displayButton.Click += new System.EventHandler(this.displayButton_Click_1);
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.emp3PositionLabel);
            this.groupBox3.Controls.Add(this.emp3DepartmentLabel);
            this.groupBox3.Controls.Add(this.emp3IDLabel);
            this.groupBox3.Controls.Add(this.emp3NameLabel);
            this.groupBox3.Controls.Add(this.label21);
            this.groupBox3.Controls.Add(this.label22);
            this.groupBox3.Controls.Add(this.label23);
            this.groupBox3.Controls.Add(this.label24);
            this.groupBox3.Location = new System.Drawing.Point(462, 12);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(219, 146);
            this.groupBox3.TabIndex = 13;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Employee 3";
            // 
            // emp3PositionLabel
            // 
            this.emp3PositionLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.emp3PositionLabel.Location = new System.Drawing.Point(77, 114);
            this.emp3PositionLabel.Name = "emp3PositionLabel";
            this.emp3PositionLabel.Size = new System.Drawing.Size(100, 23);
            this.emp3PositionLabel.TabIndex = 7;
            // 
            // emp3DepartmentLabel
            // 
            this.emp3DepartmentLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.emp3DepartmentLabel.Location = new System.Drawing.Point(77, 87);
            this.emp3DepartmentLabel.Name = "emp3DepartmentLabel";
            this.emp3DepartmentLabel.Size = new System.Drawing.Size(100, 23);
            this.emp3DepartmentLabel.TabIndex = 6;
            // 
            // emp3IDLabel
            // 
            this.emp3IDLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.emp3IDLabel.Location = new System.Drawing.Point(77, 59);
            this.emp3IDLabel.Name = "emp3IDLabel";
            this.emp3IDLabel.Size = new System.Drawing.Size(100, 23);
            this.emp3IDLabel.TabIndex = 5;
            // 
            // emp3NameLabel
            // 
            this.emp3NameLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.emp3NameLabel.Location = new System.Drawing.Point(77, 31);
            this.emp3NameLabel.Name = "emp3NameLabel";
            this.emp3NameLabel.Size = new System.Drawing.Size(100, 23);
            this.emp3NameLabel.TabIndex = 4;
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Location = new System.Drawing.Point(24, 115);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(47, 13);
            this.label21.TabIndex = 3;
            this.label21.Text = "Position:";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Location = new System.Drawing.Point(6, 88);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(65, 13);
            this.label22.TabIndex = 2;
            this.label22.Text = "Department:";
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Location = new System.Drawing.Point(15, 60);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(56, 13);
            this.label23.TabIndex = 1;
            this.label23.Text = "IdNumber:";
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Location = new System.Drawing.Point(33, 32);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(38, 13);
            this.label24.TabIndex = 0;
            this.label24.Text = "Name:";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.emp2PositionLabel);
            this.groupBox2.Controls.Add(this.emp2DepartmentLabel);
            this.groupBox2.Controls.Add(this.emp2IDLabel);
            this.groupBox2.Controls.Add(this.emp2NameLabel);
            this.groupBox2.Controls.Add(this.label13);
            this.groupBox2.Controls.Add(this.label14);
            this.groupBox2.Controls.Add(this.label15);
            this.groupBox2.Controls.Add(this.label16);
            this.groupBox2.Location = new System.Drawing.Point(237, 12);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(219, 146);
            this.groupBox2.TabIndex = 12;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Employee 2";
            // 
            // emp2PositionLabel
            // 
            this.emp2PositionLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.emp2PositionLabel.Location = new System.Drawing.Point(77, 114);
            this.emp2PositionLabel.Name = "emp2PositionLabel";
            this.emp2PositionLabel.Size = new System.Drawing.Size(100, 23);
            this.emp2PositionLabel.TabIndex = 7;
            // 
            // emp2DepartmentLabel
            // 
            this.emp2DepartmentLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.emp2DepartmentLabel.Location = new System.Drawing.Point(77, 87);
            this.emp2DepartmentLabel.Name = "emp2DepartmentLabel";
            this.emp2DepartmentLabel.Size = new System.Drawing.Size(100, 23);
            this.emp2DepartmentLabel.TabIndex = 6;
            // 
            // emp2IDLabel
            // 
            this.emp2IDLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.emp2IDLabel.Location = new System.Drawing.Point(77, 59);
            this.emp2IDLabel.Name = "emp2IDLabel";
            this.emp2IDLabel.Size = new System.Drawing.Size(100, 23);
            this.emp2IDLabel.TabIndex = 5;
            // 
            // emp2NameLabel
            // 
            this.emp2NameLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.emp2NameLabel.Location = new System.Drawing.Point(77, 31);
            this.emp2NameLabel.Name = "emp2NameLabel";
            this.emp2NameLabel.Size = new System.Drawing.Size(100, 23);
            this.emp2NameLabel.TabIndex = 4;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(24, 115);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(47, 13);
            this.label13.TabIndex = 3;
            this.label13.Text = "Position:";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(6, 88);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(65, 13);
            this.label14.TabIndex = 2;
            this.label14.Text = "Department:";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(15, 60);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(56, 13);
            this.label15.TabIndex = 1;
            this.label15.Text = "IdNumber:";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(33, 32);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(38, 13);
            this.label16.TabIndex = 0;
            this.label16.Text = "Name:";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.emp1PositionLabel);
            this.groupBox1.Controls.Add(this.emp1DepartmentLabel);
            this.groupBox1.Controls.Add(this.emp1IDLabel);
            this.groupBox1.Controls.Add(this.emp1NameLabel);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Location = new System.Drawing.Point(12, 12);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(219, 146);
            this.groupBox1.TabIndex = 11;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Employee 1";
            // 
            // emp1PositionLabel
            // 
            this.emp1PositionLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.emp1PositionLabel.Location = new System.Drawing.Point(77, 114);
            this.emp1PositionLabel.Name = "emp1PositionLabel";
            this.emp1PositionLabel.Size = new System.Drawing.Size(100, 23);
            this.emp1PositionLabel.TabIndex = 7;
            // 
            // emp1DepartmentLabel
            // 
            this.emp1DepartmentLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.emp1DepartmentLabel.Location = new System.Drawing.Point(77, 87);
            this.emp1DepartmentLabel.Name = "emp1DepartmentLabel";
            this.emp1DepartmentLabel.Size = new System.Drawing.Size(100, 23);
            this.emp1DepartmentLabel.TabIndex = 6;
            // 
            // emp1IDLabel
            // 
            this.emp1IDLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.emp1IDLabel.Location = new System.Drawing.Point(77, 59);
            this.emp1IDLabel.Name = "emp1IDLabel";
            this.emp1IDLabel.Size = new System.Drawing.Size(100, 23);
            this.emp1IDLabel.TabIndex = 5;
            // 
            // emp1NameLabel
            // 
            this.emp1NameLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.emp1NameLabel.Location = new System.Drawing.Point(77, 31);
            this.emp1NameLabel.Name = "emp1NameLabel";
            this.emp1NameLabel.Size = new System.Drawing.Size(100, 23);
            this.emp1NameLabel.TabIndex = 4;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(24, 115);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(47, 13);
            this.label4.TabIndex = 3;
            this.label4.Text = "Position:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(6, 88);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(65, 13);
            this.label3.TabIndex = 2;
            this.label3.Text = "Department:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(15, 60);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(56, 13);
            this.label2.TabIndex = 1;
            this.label2.Text = "IdNumber:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(33, 32);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(38, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Name:";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(687, 232);
            this.Controls.Add(this.exitButton);
            this.Controls.Add(this.displayButton);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Name = "Form1";
            this.Text = "Employee Info";
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button exitButton;
        private System.Windows.Forms.Button displayButton;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.Label emp3PositionLabel;
        private System.Windows.Forms.Label emp3DepartmentLabel;
        private System.Windows.Forms.Label emp3IDLabel;
        private System.Windows.Forms.Label emp3NameLabel;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Label emp2PositionLabel;
        private System.Windows.Forms.Label emp2DepartmentLabel;
        private System.Windows.Forms.Label emp2IDLabel;
        private System.Windows.Forms.Label emp2NameLabel;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label emp1PositionLabel;
        private System.Windows.Forms.Label emp1DepartmentLabel;
        private System.Windows.Forms.Label emp1IDLabel;
        private System.Windows.Forms.Label emp1NameLabel;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
    }
}

