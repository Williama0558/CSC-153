﻿/**
* 05/13/18
* CSC 153
* Aaron Williams
* This program will let the user display information about three employee
*/

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using EmployeeClassLibrary;

namespace EmployeeClass
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }


        private void getEmployee2Info(Employee employee2)
        {
            // Sets the information to the class
            employee2.Department = "IT";
            employee2.Position = "Programmer";
        }

        private void getEmployee3Info(Employee employee3)
        {
            // Sets the information to the class
            employee3.Name = "Joy Rogers";
            employee3.ID = 81774;
            employee3.Department = "Manufacturing";
            employee3.Position = "Engineer";
        }


        private void displayButton_Click_1(object sender, EventArgs e)
        {
            // Creates an object named employee 1 using the overloaded constructor
            Employee employee1 = new Employee("Susan Meyers", 47899, "Accounting", "Vice President");
            // Displays the contents of the object
            emp1NameLabel.Text = employee1.Name;
            emp1IDLabel.Text = employee1.ID.ToString();
            emp1DepartmentLabel.Text = employee1.Department;
            emp1PositionLabel.Text = employee1.Position;
            
            // Creates an object named employee 2 using the partially overloaded constructor
            Employee employee2 = new Employee("Mark Jones", 39119);
            // Gets information to store in the remaining fields of the object
            getEmployee2Info(employee2);
            // Displays the contents of the object
            emp2NameLabel.Text = employee2.Name;
            emp2IDLabel.Text = employee2.ID.ToString();
            emp2DepartmentLabel.Text = employee2.Department;
            emp2PositionLabel.Text = employee2.Position;

            // Creates an object named employee 3 using the parameterless constructor
            Employee employee3 = new Employee();
            // Gets information to store in the fields of the object
            getEmployee3Info(employee3);
            // Displays the contents of the object
            emp3NameLabel.Text = employee3.Name;
            emp3IDLabel.Text = employee3.ID.ToString();
            emp3DepartmentLabel.Text = employee3.Department;
            emp3PositionLabel.Text = employee3.Position;

        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            //Closes the program
            this.Close();
        }
    }
}
