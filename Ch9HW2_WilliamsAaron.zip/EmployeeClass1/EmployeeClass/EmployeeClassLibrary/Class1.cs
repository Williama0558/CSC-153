﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EmployeeClassLibrary
{
    public class Employee
    {
        // Fields
        private string _name;
        private int _id;
        private string _department;
        private string _position;

        // Parameterless constructor
        public Employee()
        {
            _name = "";
            _id = 0;
            _department = "";
            _position = "";
        }

        // Partially overloaded constructor
        public Employee(string name, int id)
        {
            _name = name;
            _id = id;
            _department = "";
            _position = "";
        }

        // Overloaded constructor
        public Employee(string name, int id, string department, string position)
        {
            _name = name;
            _id = id;
            _department = department;
            _position = position;
        }

        // Name property
        public string Name
        {
            get { return _name; }
            set { _name = value; }
        }

        // ID property
        public int ID
        {
            get { return _id; }
            set { _id = value; }
        }

        // Department property
        public string Department
        {
            get { return _department; }
            set { _department = value; }
        }

        // Position property
        public string Position
        {
            get { return _position; }
            set { _position = value; }
        }

    }
}