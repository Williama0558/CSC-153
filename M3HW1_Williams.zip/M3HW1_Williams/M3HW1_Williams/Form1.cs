﻿/**
* 02/21/18
* CSC 153
* Aaron Williams
* This program will show the user a Roman numeral based on the integer that they input into the program.
*/

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace M3HW1_Williams
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void romanNumeralButton_Click(object sender, EventArgs e)
        {
            try
            {
                int userNumber; //To hold the number the user inputs

                // Validate the integerTextBox control.
                if (int.TryParse(integerTextBox.Text, out userNumber))
                {
                    // Validates the number inputted by the user.
                    if (userNumber >= 1 && userNumber <= 10)
                    {
                        // Determines what Roman numeral to show based on the number that the user inputted.
                        switch (userNumber)
                        {
                            case 1:
                                romanNumeralLabel.Text = "I";
                                break;

                            case 2:
                                romanNumeralLabel.Text = "II";
                                break;

                            case 3:
                                romanNumeralLabel.Text = "III";
                                break;

                            case 4:
                                romanNumeralLabel.Text = "IV";
                                break;

                            case 5:
                                romanNumeralLabel.Text = "V";
                                break;

                            case 6:
                                romanNumeralLabel.Text = "VI";
                                break;

                            case 7:
                                romanNumeralLabel.Text = "VII";
                                break;

                            case 8:
                                romanNumeralLabel.Text = "VIII";
                                break;

                            case 9:
                                romanNumeralLabel.Text = "IX";
                                break;

                            case 10:
                                romanNumeralLabel.Text = "X";
                                break;
                        }
                    }

                    else
                    {
                        MessageBox.Show("Integer must be a value greater than 0 and less than 11");
                    }
                }

                else
                {
                    // Will be displayed if the user enters in something besides an integer.
                    MessageBox.Show("Invalid input for the integer text box.");
                }
            }

            catch (Exception ex)
            {
                // Display an error message.
                MessageBox.Show(ex.Message);
            }
        }

        private void clearButton_Click(object sender, EventArgs e)
        {
            // Clears the values from the text box and the label.
            integerTextBox.Text = "";
            romanNumeralLabel.Text = "";

            // Resets the cursor to the integer text box.
            integerTextBox.Focus();
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            // Ends the program.
            this.Close();
        }
    }
}