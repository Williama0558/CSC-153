﻿namespace M3HW1_Williams
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.integerLabel = new System.Windows.Forms.Label();
            this.rNumeralLabel = new System.Windows.Forms.Label();
            this.integerTextBox = new System.Windows.Forms.TextBox();
            this.romanNumeralLabel = new System.Windows.Forms.Label();
            this.romanNumeralButton = new System.Windows.Forms.Button();
            this.clearButton = new System.Windows.Forms.Button();
            this.exitButton = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // integerLabel
            // 
            this.integerLabel.AutoSize = true;
            this.integerLabel.Location = new System.Drawing.Point(60, 34);
            this.integerLabel.Name = "integerLabel";
            this.integerLabel.Size = new System.Drawing.Size(43, 13);
            this.integerLabel.TabIndex = 0;
            this.integerLabel.Text = "Integer:";
            // 
            // rNumeralLabel
            // 
            this.rNumeralLabel.AutoSize = true;
            this.rNumeralLabel.Location = new System.Drawing.Point(17, 70);
            this.rNumeralLabel.Name = "rNumeralLabel";
            this.rNumeralLabel.Size = new System.Drawing.Size(86, 13);
            this.rNumeralLabel.TabIndex = 1;
            this.rNumeralLabel.Text = "Roman Numeral:";
            // 
            // integerTextBox
            // 
            this.integerTextBox.Location = new System.Drawing.Point(109, 31);
            this.integerTextBox.Name = "integerTextBox";
            this.integerTextBox.Size = new System.Drawing.Size(100, 20);
            this.integerTextBox.TabIndex = 2;
            // 
            // romanNumeralLabel
            // 
            this.romanNumeralLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.romanNumeralLabel.Location = new System.Drawing.Point(109, 65);
            this.romanNumeralLabel.Name = "romanNumeralLabel";
            this.romanNumeralLabel.Size = new System.Drawing.Size(100, 23);
            this.romanNumeralLabel.TabIndex = 3;
            this.romanNumeralLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // romanNumeralButton
            // 
            this.romanNumeralButton.Location = new System.Drawing.Point(20, 114);
            this.romanNumeralButton.Name = "romanNumeralButton";
            this.romanNumeralButton.Size = new System.Drawing.Size(75, 34);
            this.romanNumeralButton.TabIndex = 4;
            this.romanNumeralButton.Text = "&Get Roman Numeral";
            this.romanNumeralButton.UseVisualStyleBackColor = true;
            this.romanNumeralButton.Click += new System.EventHandler(this.romanNumeralButton_Click);
            // 
            // clearButton
            // 
            this.clearButton.Location = new System.Drawing.Point(101, 114);
            this.clearButton.Name = "clearButton";
            this.clearButton.Size = new System.Drawing.Size(75, 34);
            this.clearButton.TabIndex = 5;
            this.clearButton.Text = "&Clear";
            this.clearButton.UseVisualStyleBackColor = true;
            this.clearButton.Click += new System.EventHandler(this.clearButton_Click);
            // 
            // exitButton
            // 
            this.exitButton.Location = new System.Drawing.Point(182, 114);
            this.exitButton.Name = "exitButton";
            this.exitButton.Size = new System.Drawing.Size(75, 34);
            this.exitButton.TabIndex = 6;
            this.exitButton.Text = "&Exit";
            this.exitButton.UseVisualStyleBackColor = true;
            this.exitButton.Click += new System.EventHandler(this.exitButton_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(284, 174);
            this.Controls.Add(this.exitButton);
            this.Controls.Add(this.clearButton);
            this.Controls.Add(this.romanNumeralButton);
            this.Controls.Add(this.romanNumeralLabel);
            this.Controls.Add(this.integerTextBox);
            this.Controls.Add(this.rNumeralLabel);
            this.Controls.Add(this.integerLabel);
            this.Name = "Form1";
            this.Text = "Roman Numeral Converter";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label integerLabel;
        private System.Windows.Forms.Label rNumeralLabel;
        private System.Windows.Forms.TextBox integerTextBox;
        private System.Windows.Forms.Label romanNumeralLabel;
        private System.Windows.Forms.Button romanNumeralButton;
        private System.Windows.Forms.Button clearButton;
        private System.Windows.Forms.Button exitButton;
    }
}

