﻿/**
* 03/04/2018
* CSC 153
* Aaron Williams
* This program will calculate a discount based on the amount of software a user purchases.
*/

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace M3HW2_Williams
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void calculateButton_Click(object sender, EventArgs e)
        {
            try
            {
                // Variables and constants for the program
                const decimal PACKAGE_COST = 99m;

                int packages;
                decimal discount;
                decimal discountAmount;
                decimal totalAmount;

                if (int.TryParse(purchasedTextBox.Text, out packages))
                {
                    // Determines how much of a discount to give the user based on the amount they purchase.
                    if (packages < 10)
                    {
                        totalAmount = packages * PACKAGE_COST;
                        discountLabel.Text = "";
                        totalLabel.Text = totalAmount.ToString("c");
                    }
                    else if (packages >= 10 && packages <= 19)
                    {
                        // Determines the total cost before the discount
                        decimal totalCost = packages * PACKAGE_COST;
                        // The discount amount
                        discount = .20m;
                        // How much of a discount the user will get
                        discountAmount = totalCost * discount;
                        // Displays the discount
                        discountLabel.Text = discountAmount.ToString("c");
                        // Calculates the total amount after discount is applied
                        totalAmount = totalCost - discountAmount;
                        // Displays the total cost
                        totalLabel.Text = totalAmount.ToString("c");
                    }
                    else if (packages >= 20 && packages <= 49)
                    {
                        decimal totalCost = packages * PACKAGE_COST;
                        discount = .30m;
                        discountAmount = totalCost * discount;
                        discountLabel.Text = discountAmount.ToString("c");
                        totalAmount = totalCost - discountAmount;
                        totalLabel.Text = totalAmount.ToString("c");
                    }
                    else if (packages >= 50 && packages <= 99)
                    {
                        decimal totalCost = packages * PACKAGE_COST;
                        discount = .40m;
                        discountAmount = totalCost * discount;
                        discountLabel.Text = discountAmount.ToString("c");
                        totalAmount = totalCost - discountAmount;
                        totalLabel.Text = totalAmount.ToString("c");
                    }
                    else
                    {
                        decimal totalCost = packages * PACKAGE_COST;
                        discount = .50m;
                        discountAmount = totalCost * discount;
                        discountLabel.Text = discountAmount.ToString("c");
                        totalAmount = totalCost - discountAmount;
                        totalLabel.Text = totalAmount.ToString("c");
                    }
                }
                else
                {
                    // Displays an error if anything but an interger is inputted
                    MessageBox.Show("Invalid input for the packages text box");
                }
            }


            catch (Exception ex)
            {
                // Shows an error message
                MessageBox.Show(ex.Message);
            }
        }

        private void clearButton_Click(object sender, EventArgs e)
        {
            // Clears value from labels and text boxes
            purchasedTextBox.Text = "";
            discountLabel.Text = "";
            totalLabel.Text = "";

            // Resets focus to the text box
            purchasedTextBox.Focus();
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            // Ends program
            this.Close();
        }
    }
}
