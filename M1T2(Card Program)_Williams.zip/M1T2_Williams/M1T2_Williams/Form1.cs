﻿/**
* 01/31/18
* CSC 153
* Aaron Williams
* This program will show the user the front and back of a card
*/
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace M1T2_Williams
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            //Make the back of the card visible
            cardBackPictureBox.Visible = true;
            //Make the back of the card invisible
            cardFacePictureBox.Visible = false;
        }

        private void showFaceButton_Click(object sender, EventArgs e)
        {
            //Make the face of the card invisible
            cardBackPictureBox.Visible = false;
            //Make the face of the card visible
            cardFacePictureBox.Visible = true;
        }

    }
}
