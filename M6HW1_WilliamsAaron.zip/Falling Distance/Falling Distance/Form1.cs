﻿/**
* 04/22/2018
* CSC 153
* Aaron Williams
* This program will calculate how far an object has fallen in a specified time frame
*/

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Falling_Distance
{
    public partial class Form1 : Form
    {
        // Constants of the formula
        private const double GRAVITY_ACCELERATION = 9.8;
        private const double FORMULA_DECIMAL = .5;
        public Form1()
        {
            InitializeComponent();
        }

        // Method that will calculate the distance fallen.
        private void FallingDistance(double timeFallen)
        {
            // Variable to hold how far an object has fallen
            double distanceFallen; 
            // Calculates how a far an object has fallen
            distanceFallen = FORMULA_DECIMAL * GRAVITY_ACCELERATION * (timeFallen * timeFallen);
            distanceFallenLabel.Text = distanceFallen.ToString();
        }

        // Method that will find the distance an object has fallen.
        private bool CheckingInput(ref double timeFallen)
        {
            try
            {
                // Bool variable for checking if user input is valid.
                bool validInput = false;

                // Try to convert input to double
                if (double.TryParse(timeFallenTextBox.Text, out timeFallen))
                {
                    validInput = true;
                }
                // Shown if invalid input entered
                else
                {
                    MessageBox.Show("Invalid input for time fallen");
                }
                return validInput;
            }
            catch(Exception ex)
            {
                bool validInput = false;
                MessageBox.Show(ex.Message);
                return validInput;
            }
        }

        private void calculateButton_Click(object sender, EventArgs e)
        {
            // Variables
            double timeFallen = 0;
            // If the input is valid, sends user input to the method to calculate fall distance
            if (CheckingInput(ref timeFallen))
            {
                FallingDistance(timeFallen);
            }
            // Shown if invalid input is entered
            else
            {
                MessageBox.Show("Invalid input for time fallen");
            }
        }

        private void clearButton_Click(object sender, EventArgs e)
        {
            // Clears the label and textbox
            timeFallenTextBox.Text = "";
            distanceFallenLabel.Text = "";
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            // Closes the program
            this.Close();
        }
    }
}
