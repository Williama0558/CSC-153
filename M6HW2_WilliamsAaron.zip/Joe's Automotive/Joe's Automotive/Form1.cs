﻿/**
* 04/22/2018
* CSC 153
* Aaron Williams
* This program will calculate the costs of buying from an automotive shop.
*/

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Joe_s_Automotive
{
    public partial class Form1 : Form
    {
        // Constants for the program
        private const decimal OIL_COST = 26.00m;
        private const decimal LUBE_COST = 18.00m;
        private const decimal INSPECTION_COST = 15.00m;
        private const decimal MUFFLER_COST = 100.00m;
        private const decimal TIRE_ROTATION_COST = 20.00m;
        private const decimal RADIATOR_COST = 30.00m;
        private const decimal TRANSMISSION_COST = 80.00m;
        private const decimal SALES_TAX = .06m;
        private decimal serviceCost = 0m;
        public Form1()
        {
            InitializeComponent();
        }

        // Method for calculating the cost for the oil and lube group box
        private decimal OilLubeCharges(decimal serviceCost)
        {
            // If-else tree that depends on which checkboxes the user clicks on
            // Returns the costs of the selected checkboxes back to the main click event button
            if ((oilCheckBox.Checked == true) && (lubeCheckBox.Checked == true))
            {
                serviceCost += OIL_COST + LUBE_COST;
                return serviceCost;
            }
            else if (oilCheckBox.Checked == true)
            {
                serviceCost += OIL_COST;
                return serviceCost;
            }
            else if (lubeCheckBox.Checked == true)
            {
                serviceCost += LUBE_COST;
                return serviceCost;
            }
            else
            {
                return serviceCost;
            }

        }

        // Method for calculating the cost for the flush charges group box
        private decimal FlushCharges(decimal serviceCost)
        {
            // If-else tree that depends on which checkboxes the user clicks on
            // Returns the costs of the selected checkboxes back to the main click event button
            if ((radiatorCheckBox.Checked == true) && (transmissionCheckBox.Checked == true))
            {
                serviceCost += RADIATOR_COST + TRANSMISSION_COST;
                return serviceCost;
            }
            else if (radiatorCheckBox.Checked == true)
            {
                serviceCost += RADIATOR_COST;
                return serviceCost;
            }
            else if (transmissionCheckBox.Checked == true)
            {
                serviceCost += TRANSMISSION_COST;
                return serviceCost;
            }
            else
            {
                return serviceCost;
            }


        }

        // Method for calculating costs from the misc group box
        private decimal MiscCharges(decimal serviceCost)
        {
            // If-else tree that depends on which checkboxes the user clicks on
            // Returns the costs of the selected checkboxes back to the main click event button
            if ((inspectionCheckBox.Checked == true) && (mufflerCheckBox.Checked == true) && (rotationCheckBox.Checked == true))
            {
                serviceCost += INSPECTION_COST + MUFFLER_COST + TIRE_ROTATION_COST;
                return serviceCost;
            }
            else if ((inspectionCheckBox.Checked == true) && (mufflerCheckBox.Checked == true))
            {
                serviceCost += INSPECTION_COST + MUFFLER_COST;
                return serviceCost;
            }
            else if ((mufflerCheckBox.Checked == true) && (rotationCheckBox.Checked == true))
            {
                serviceCost += MUFFLER_COST + TIRE_ROTATION_COST;
                return serviceCost;
            }
            else if ((inspectionCheckBox.Checked == true) && (rotationCheckBox.Checked == true))
            {
                serviceCost += INSPECTION_COST + TIRE_ROTATION_COST;
                return serviceCost;
            }
            else if (inspectionCheckBox.Checked == true)
            {
                serviceCost += INSPECTION_COST;
                return serviceCost;
            }
            else if (mufflerCheckBox.Checked == true)
            {
                serviceCost += MUFFLER_COST;
                return serviceCost;
            }
            else if (rotationCheckBox.Checked == true)
            {
                serviceCost += TIRE_ROTATION_COST;
                return serviceCost;
            }
            else
            {
                return serviceCost;
            }
        }

        // Method for calculating other costs
        private decimal OtherCharges()
        {
            // Variables
            decimal partsCost;
            decimal laborCost;
            // If-else tree that depends on which boxes the user clicks on, and then adds those costs to the total
            if (decimal.TryParse(partsTextBox.Text, out partsCost) && (decimal.TryParse(laborTextBox.Text, out laborCost)))
            {
                serviceCost += laborCost;
                partsLabel.Text = partsCost.ToString();
                return partsCost;
            }
            else if (decimal.TryParse(partsTextBox.Text, out partsCost))
            {
                partsLabel.Text = partsCost.ToString();
                return partsCost;
            }
            else if ((decimal.TryParse(laborTextBox.Text, out laborCost)))
            {
                serviceCost += laborCost;
            }
            else
            {
                return laborCost;
            }
            return partsCost;
        }

        private decimal TaxCharges(decimal partsCost)
        {
            decimal partsTax = partsCost * SALES_TAX;
            taxLabel.Text = partsTax.ToString();
            return partsTax;
        }

        private void totalCharges(decimal serviceCosts, decimal partsTax, decimal partsCost)
        {
            decimal totalCost = serviceCosts + partsTax + partsCost;
            feesLabel.Text = totalCost.ToString();
        }

        // Methods for clearing the form of user input
        private void ClearOilLube()
        {
            oilCheckBox.Checked = false;
            lubeCheckBox.Checked = false;
        }

        private void ClearFlushes()
        {
            radiatorCheckBox.Checked = false;
            transmissionCheckBox.Checked = false;
        }

        private void ClearMisc()
        {
            inspectionCheckBox.Checked = false;
            mufflerCheckBox.Checked = false;
            rotationCheckBox.Checked = false;
        }

        private void ClearOther()
        {
            partsTextBox.Text = " ";
            laborTextBox.Text = " ";
        }

        private void ClearFees()
        {
            serviceLabel.Text = " ";
            partsLabel.Text = " ";
            taxLabel.Text = " ";
            feesLabel.Text = " ";
        }

        private void calculateButton_Click(object sender, EventArgs e)
        {
            // Initializing variables
            decimal partsCost = 0;
            decimal partsTax = 0;
            // Getting the cost for services from various methods
            serviceCost =+ OilLubeCharges(serviceCost) + FlushCharges(serviceCost) + MiscCharges(serviceCost);
            // Gets the cost of parts
            partsCost = OtherCharges();
            // Gets the tax for parts
            partsTax = TaxCharges(partsCost);
            // Sends variables holding costs to the method for calculating the final cost
            totalCharges(serviceCost, partsCost, partsTax);
            // Sends services cost to a label to show output
            serviceLabel.Text = '$' + serviceCost.ToString();
            // Resets the service cost
            serviceCost = 0;
        }

        private void clearButton_Click(object sender, EventArgs e)
        {
            // Calls methods to clear the form of user input
            ClearOilLube();
            ClearFlushes();
            ClearMisc();
            ClearOther();
            ClearFees();
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            // Closes the program
            this.Close();
        }
    }
}
