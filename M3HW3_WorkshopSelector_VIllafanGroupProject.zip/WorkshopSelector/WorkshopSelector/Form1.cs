﻿/**
* 20180227
* CSC 153
* Group #3 (Michel Villafan, Anthony Wallace, Aaron Williams) 
* 
* GUI and Source code by: Michel Villafan
* FlowChart by:
* Pseudo code by:
* 
* Workshop selector, using listboxes calculate costs related to trainig workshops.
*/
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WorkshopSelector
{
    public partial class workshopSelector : Form
    {
        public workshopSelector()
        {
            InitializeComponent();
        }

        private void calculateButton_Click(object sender, EventArgs e)
        {
            //Used for listbox selections
            int selection1; //workshop type
            int selection2; //workshop location
            //String for names
            String workshopType;
            String workshopLocation;
            //Number of days
            int numOfDays = 0;
            //Registration Fee
            double regFee = 0;
            //Lodging Fee per day
            double lodgeFee = 0;
            double lodgeCost = 0;
            double totalCost = 0;

            /*     
                  Index chart for "selection 1" (Workshop Type)

            Workshop:             Index:
            Handling Stress         0
            Time Management         1
            Supervision Skills      2
            Negotiation             3
            How to interview        4

                Index chart for "selection 2" (Workshop location)
            Location:            Index:
            Austin                  0
            Chicago                 1
            Dallas                  2
            Orlando                 3
            Phoenix                 4
            Raleigh                 5

            */
            selection1 = workshopListbox.SelectedIndex;
            selection2 = locationListbox.SelectedIndex;

            /*
             *  Selection1 == 0 
             */

            if (selection1 == 0 && selection2 ==0)
            {
                //Set variables provided that correspond with each workshop type and location
                workshopType = "Handling Stress";
                numOfDays = 3;
                regFee = 1000;
                workshopLocation = "Austin";
                lodgeFee = 150;

                //Calculate lodge cost by multiplying cost per day times number of days
                lodgeCost = lodgeFee * numOfDays;
                //Calculate total by adding lodge cost and regisatration fee
                totalCost = lodgeCost + regFee;
                //Display output 
                outputRegistrationLabel.Text = regFee.ToString();
                outputLodgingLabel.Text = lodgeCost.ToString();
                outputTotalLabel.Text = totalCost.ToString(); 
            }
            else if (selection1 == 0 && selection2 == 1)
            {
                //Set variables provided that correspond with each workshop type and location
                workshopType = "Handling Stress";
                numOfDays = 3;
                regFee = 1000;
                workshopLocation = "Chicago";
                lodgeFee = 225;

                //Calculate lodge cost by multiplying cost per day times number of days
                lodgeCost = lodgeFee * numOfDays;
                //Calculate total by adding lodge cost and regisatration fee
                totalCost = lodgeCost + regFee;
                //Display output 
                outputRegistrationLabel.Text = regFee.ToString();
                outputLodgingLabel.Text = lodgeCost.ToString();
                outputTotalLabel.Text = totalCost.ToString();
            }
            else if (selection1 == 0 && selection2 == 2)
            {
                //Set variables provided that correspond with each workshop type and location
                workshopType = "Handling Stress";
                numOfDays = 3;
                regFee = 1000;
                workshopLocation = "Dallas";
                lodgeFee = 175;

                //Calculate lodge cost by multiplying cost per day times number of days
                lodgeCost = lodgeFee * numOfDays;
                //Calculate total by adding lodge cost and regisatration fee
                totalCost = lodgeCost + regFee;
                //Display output 
                outputRegistrationLabel.Text = regFee.ToString();
                outputLodgingLabel.Text = lodgeCost.ToString();
                outputTotalLabel.Text = totalCost.ToString();
            }
            else if (selection1 == 0 && selection2 == 3)
            {
                //Set variables provided that correspond with each workshop type and location
                workshopType = "Handling Stress";
                numOfDays = 3;
                regFee = 1000;
                workshopLocation = "Orlando";
                lodgeFee = 300;

                //Calculate lodge cost by multiplying cost per day times number of days
                lodgeCost = lodgeFee * numOfDays;
                //Calculate total by adding lodge cost and regisatration fee
                totalCost = lodgeCost + regFee;
                //Display output 
                outputRegistrationLabel.Text = regFee.ToString();
                outputLodgingLabel.Text = lodgeCost.ToString();
                outputTotalLabel.Text = totalCost.ToString();
            }
            else if (selection1 == 0 && selection2 == 4)
            {
                //Set variables provided that correspond with each workshop type and location
                workshopType = "Handling Stress";
                numOfDays = 3;
                regFee = 1000;
                workshopLocation = "Phoenix";
                lodgeFee = 175;

                //Calculate lodge cost by multiplying cost per day times number of days
                lodgeCost = lodgeFee * numOfDays;
                //Calculate total by adding lodge cost and regisatration fee
                totalCost = lodgeCost + regFee;
                //Display output 
                outputRegistrationLabel.Text = regFee.ToString();
                outputLodgingLabel.Text = lodgeCost.ToString();
                outputTotalLabel.Text = totalCost.ToString();
            }
            else if (selection1 == 0 && selection2 == 5)
            {
                //Set variables provided that correspond with each workshop type and location
                workshopType = "Handling Stress";
                numOfDays = 3;
                regFee = 1000;
                workshopLocation = "Raleigh";
                lodgeFee = 150;

                //Calculate lodge cost by multiplying cost per day times number of days
                lodgeCost = lodgeFee * numOfDays;
                //Calculate total by adding lodge cost and regisatration fee
                totalCost = lodgeCost + regFee;
                //Display output 
                outputRegistrationLabel.Text = regFee.ToString();
                outputLodgingLabel.Text = lodgeCost.ToString();
                outputTotalLabel.Text = totalCost.ToString();
            }

            /*
             *  Selection1 == 1 
             */

            if (selection1 == 1 && selection2 == 0)
            {
                //Set variables provided that correspond with each workshop type and location
                workshopType = "Time Management";
                numOfDays = 3;
                regFee = 800;
                workshopLocation = "Austin";
                lodgeFee = 150;

                //Calculate lodge cost by multiplying cost per day times number of days
                lodgeCost = lodgeFee * numOfDays;
                //Calculate total by adding lodge cost and regisatration fee
                totalCost = lodgeCost + regFee;
                //Display output 
                outputRegistrationLabel.Text = regFee.ToString();
                outputLodgingLabel.Text = lodgeCost.ToString();
                outputTotalLabel.Text = totalCost.ToString();
            }
            else if (selection1 == 1 && selection2 == 1)
            {
                //Set variables provided that correspond with each workshop type and location
                workshopType = "Time Management";
                numOfDays = 3;
                regFee = 800;
                workshopLocation = "Chicago";
                lodgeFee = 225;

                //Calculate lodge cost by multiplying cost per day times number of days
                lodgeCost = lodgeFee * numOfDays;
                //Calculate total by adding lodge cost and regisatration fee
                totalCost = lodgeCost + regFee;
                //Display output 
                outputRegistrationLabel.Text = regFee.ToString();
                outputLodgingLabel.Text = lodgeCost.ToString();
                outputTotalLabel.Text = totalCost.ToString();
            }
            else if (selection1 == 1 && selection2 == 2)
            {
                //Set variables provided that correspond with each workshop type and location
                workshopType = "Time Management";
                numOfDays = 3;
                regFee = 800;
                workshopLocation = "Dallas";
                lodgeFee = 175;

                //Calculate lodge cost by multiplying cost per day times number of days
                lodgeCost = lodgeFee * numOfDays;
                //Calculate total by adding lodge cost and regisatration fee
                totalCost = lodgeCost + regFee;
                //Display output 
                outputRegistrationLabel.Text = regFee.ToString();
                outputLodgingLabel.Text = lodgeCost.ToString();
                outputTotalLabel.Text = totalCost.ToString();
            }
            else if (selection1 == 1 && selection2 == 3)
            {
                //Set variables provided that correspond with each workshop type and location
                workshopType = "Time Management";
                numOfDays = 3;
                regFee = 800;
                workshopLocation = "Orlando";
                lodgeFee = 300;

                //Calculate lodge cost by multiplying cost per day times number of days
                lodgeCost = lodgeFee * numOfDays;
                //Calculate total by adding lodge cost and regisatration fee
                totalCost = lodgeCost + regFee;
                //Display output 
                outputRegistrationLabel.Text = regFee.ToString();
                outputLodgingLabel.Text = lodgeCost.ToString();
                outputTotalLabel.Text = totalCost.ToString();
            }
            else if (selection1 == 1 && selection2 == 4)
            {
                //Set variables provided that correspond with each workshop type and location
                workshopType = "Time Management";
                numOfDays = 3;
                regFee = 800;
                workshopLocation = "Phoenix";
                lodgeFee = 175;

                //Calculate lodge cost by multiplying cost per day times number of days
                lodgeCost = lodgeFee * numOfDays;
                //Calculate total by adding lodge cost and regisatration fee
                totalCost = lodgeCost + regFee;
                //Display output 
                outputRegistrationLabel.Text = regFee.ToString();
                outputLodgingLabel.Text = lodgeCost.ToString();
                outputTotalLabel.Text = totalCost.ToString();
            }
            else if (selection1 == 1 && selection2 == 5)
            {
                //Set variables provided that correspond with each workshop type and location
                workshopType = "Time Management";
                numOfDays = 3;
                regFee = 800;
                workshopLocation = "Raleigh";
                lodgeFee = 150;

                //Calculate lodge cost by multiplying cost per day times number of days
                lodgeCost = lodgeFee * numOfDays;
                //Calculate total by adding lodge cost and regisatration fee
                totalCost = lodgeCost + regFee;
                //Display output 
                outputRegistrationLabel.Text = regFee.ToString();
                outputLodgingLabel.Text = lodgeCost.ToString();
                outputTotalLabel.Text = totalCost.ToString();
            }
            /*
             *  Selection1 == 2
             */

            if (selection1 == 2 && selection2 == 0)
            {
                //Set variables provided that correspond with each workshop type and location
                workshopType = "Supervision Skills";
                numOfDays = 3;
                regFee = 1500;
                workshopLocation = "Austin";
                lodgeFee = 150;

                //Calculate lodge cost by multiplying cost per day times number of days
                lodgeCost = lodgeFee * numOfDays;
                //Calculate total by adding lodge cost and regisatration fee
                totalCost = lodgeCost + regFee;
                //Display output 
                outputRegistrationLabel.Text = regFee.ToString();
                outputLodgingLabel.Text = lodgeCost.ToString();
                outputTotalLabel.Text = totalCost.ToString();
            }
            else if (selection1 == 2 && selection2 == 1)
            {
                //Set variables provided that correspond with each workshop type and location
                workshopType = "Supervision Skills";
                numOfDays = 3;
                regFee = 1500;
                workshopLocation = "Chicago";
                lodgeFee = 225;

                //Calculate lodge cost by multiplying cost per day times number of days
                lodgeCost = lodgeFee * numOfDays;
                //Calculate total by adding lodge cost and regisatration fee
                totalCost = lodgeCost + regFee;
                //Display output 
                outputRegistrationLabel.Text = regFee.ToString();
                outputLodgingLabel.Text = lodgeCost.ToString();
                outputTotalLabel.Text = totalCost.ToString();
            }
            else if (selection1 == 2 && selection2 == 2)
            {
                //Set variables provided that correspond with each workshop type and location
                workshopType = "Supervision Skills";
                numOfDays = 3;
                regFee = 1500;
                workshopLocation = "Dallas";
                lodgeFee = 175;

                //Calculate lodge cost by multiplying cost per day times number of days
                lodgeCost = lodgeFee * numOfDays;
                //Calculate total by adding lodge cost and regisatration fee
                totalCost = lodgeCost + regFee;
                //Display output 
                outputRegistrationLabel.Text = regFee.ToString();
                outputLodgingLabel.Text = lodgeCost.ToString();
                outputTotalLabel.Text = totalCost.ToString();
            }
            else if (selection1 == 2 && selection2 == 3)
            {
                //Set variables provided that correspond with each workshop type and location
                workshopType = "Supervision Skills";
                numOfDays = 3;
                regFee = 1500;
                workshopLocation = "Orlando";
                lodgeFee = 300;

                //Calculate lodge cost by multiplying cost per day times number of days
                lodgeCost = lodgeFee * numOfDays;
                //Calculate total by adding lodge cost and regisatration fee
                totalCost = lodgeCost + regFee;
                //Display output 
                outputRegistrationLabel.Text = regFee.ToString();
                outputLodgingLabel.Text = lodgeCost.ToString();
                outputTotalLabel.Text = totalCost.ToString();
            }
            else if (selection1 == 2 && selection2 == 4)
            {
                //Set variables provided that correspond with each workshop type and location
                workshopType = "Supervision Skills";
                numOfDays = 3;
                regFee = 1500;
                workshopLocation = "Phoenix";
                lodgeFee = 175;

                //Calculate lodge cost by multiplying cost per day times number of days
                lodgeCost = lodgeFee * numOfDays;
                //Calculate total by adding lodge cost and regisatration fee
                totalCost = lodgeCost + regFee;
                //Display output 
                outputRegistrationLabel.Text = regFee.ToString();
                outputLodgingLabel.Text = lodgeCost.ToString();
                outputTotalLabel.Text = totalCost.ToString();
            }
            else if (selection1 == 2 && selection2 == 5)
            {
                //Set variables provided that correspond with each workshop type and location
                workshopType = "Supervision Skills";
                numOfDays = 3;
                regFee = 1500;
                workshopLocation = "Raleigh";
                lodgeFee = 150;

                //Calculate lodge cost by multiplying cost per day times number of days
                lodgeCost = lodgeFee * numOfDays;
                //Calculate total by adding lodge cost and regisatration fee
                totalCost = lodgeCost + regFee;
                //Display output 
                outputRegistrationLabel.Text = regFee.ToString();
                outputLodgingLabel.Text = lodgeCost.ToString();
                outputTotalLabel.Text = totalCost.ToString();
            }
            /*
             *  Selection1 == 3
             */

            if (selection1 == 3 && selection2 == 0)
            {
                //Set variables provided that correspond with each workshop type and location
                workshopType = "Negotiation";
                numOfDays = 5;
                regFee = 1300;
                workshopLocation = "Austin";
                lodgeFee = 150;

                //Calculate lodge cost by multiplying cost per day times number of days
                lodgeCost = lodgeFee * numOfDays;
                //Calculate total by adding lodge cost and regisatration fee
                totalCost = lodgeCost + regFee;
                //Display output 
                outputRegistrationLabel.Text = regFee.ToString();
                outputLodgingLabel.Text = lodgeCost.ToString();
                outputTotalLabel.Text = totalCost.ToString();
            }
            else if (selection1 == 3 && selection2 == 1)
            {
                //Set variables provided that correspond with each workshop type and location
                workshopType = "Negotiation";
                numOfDays = 5;
                regFee = 1300;
                workshopLocation = "Chicago";
                lodgeFee = 225;

                //Calculate lodge cost by multiplying cost per day times number of days
                lodgeCost = lodgeFee * numOfDays;
                //Calculate total by adding lodge cost and regisatration fee
                totalCost = lodgeCost + regFee;
                //Display output
                outputRegistrationLabel.Text = regFee.ToString();
                outputLodgingLabel.Text = lodgeCost.ToString();
                outputTotalLabel.Text = totalCost.ToString();
            }
            else if (selection1 == 3 && selection2 == 2)
            {
                //Set variables provided that correspond with each workshop type and location
                workshopType = "Negotiation";
                numOfDays = 5;
                regFee = 1300;
                workshopLocation = "Dallas";
                lodgeFee = 175;

                //Calculate lodge cost by multiplying cost per day times number of days
                lodgeCost = lodgeFee * numOfDays;
                //Calculate total by adding lodge cost and regisatration fee
                totalCost = lodgeCost + regFee;
                //Display output 
                outputRegistrationLabel.Text = regFee.ToString();
                outputLodgingLabel.Text = lodgeCost.ToString();
                outputTotalLabel.Text = totalCost.ToString();
            }
            else if (selection1 == 3 && selection2 == 3)
            {
                //Set variables provided that correspond with each workshop type and location
                workshopType = "Negotiation";
                numOfDays = 5;
                regFee = 1300;
                workshopLocation = "Orlando";
                lodgeFee = 300;

                //Calculate lodge cost by multiplying cost per day times number of days
                lodgeCost = lodgeFee * numOfDays;
                //Calculate total by adding lodge cost and regisatration fee
                totalCost = lodgeCost + regFee;
                //Display output
                outputRegistrationLabel.Text = regFee.ToString();
                outputLodgingLabel.Text = lodgeCost.ToString();
                outputTotalLabel.Text = totalCost.ToString();
            }
            else if (selection1 == 3 && selection2 == 4)
            {
                //Set variables provided that correspond with each workshop type and location
                workshopType = "Negotiation";
                numOfDays = 5;
                regFee = 1300;
                workshopLocation = "Phoenix";
                lodgeFee = 175;

                //Calculate lodge cost by multiplying cost per day times number of days
                lodgeCost = lodgeFee * numOfDays;
                //Calculate total by adding lodge cost and regisatration fee
                totalCost = lodgeCost + regFee;
                //Display output 
                outputRegistrationLabel.Text = regFee.ToString();
                outputLodgingLabel.Text = lodgeCost.ToString();
                outputTotalLabel.Text = totalCost.ToString();
            }
            else if (selection1 == 3 && selection2 == 5)
            {
                //Set variables provided that correspond with each workshop type and location
                workshopType = "Negotiation";
                numOfDays = 5;
                regFee = 1300;
                workshopLocation = "Raleigh";
                lodgeFee = 150;

                //Calculate lodge cost by multiplying cost per day times number of days
                lodgeCost = lodgeFee * numOfDays;
                //Calculate total by adding lodge cost and regisatration fee
                totalCost = lodgeCost + regFee;
                //Display output 
                outputRegistrationLabel.Text = regFee.ToString();
                outputLodgingLabel.Text = lodgeCost.ToString();
                outputTotalLabel.Text = totalCost.ToString();
            }
            /*
             *  Selection1 == 4
             */

            if (selection1 == 4 && selection2 == 0)
            {
                //Set variables provided that correspond with each workshop type and location
                workshopType = "How to Interview";
                numOfDays = 1;
                regFee = 500;
                workshopLocation = "Austin";
                lodgeFee = 150;

                //Calculate lodge cost by multiplying cost per day times number of days
                lodgeCost = lodgeFee * numOfDays;
                //Calculate total by adding lodge cost and regisatration fee
                totalCost = lodgeCost + regFee;
                //Display output 
                outputRegistrationLabel.Text = regFee.ToString();
                outputLodgingLabel.Text = lodgeCost.ToString();
                outputTotalLabel.Text = totalCost.ToString();
            }
            else if (selection1 == 4 && selection2 == 1)
            {
                //Set variables provided that correspond with each workshop type and location
                workshopType = "How to Interview";
                numOfDays = 1;
                regFee = 500;
                workshopLocation = "Chicago";
                lodgeFee = 225;

                //Calculate lodge cost by multiplying cost per day times number of days
                lodgeCost = lodgeFee * numOfDays;
                //Calculate total by adding lodge cost and regisatration fee
                totalCost = lodgeCost + regFee;
                //Display output 
                outputRegistrationLabel.Text = regFee.ToString();
                outputLodgingLabel.Text = lodgeCost.ToString();
                outputTotalLabel.Text = totalCost.ToString();
            }
            else if (selection1 == 4 && selection2 == 2)
            {
                //Set variables provided that correspond with each workshop type and location
                workshopType = "How to Interview";
                numOfDays = 1;
                regFee = 500;
                workshopLocation = "Dallas";
                lodgeFee = 175;

                //Calculate lodge cost by multiplying cost per day times number of days
                lodgeCost = lodgeFee * numOfDays;
                //Calculate total by adding lodge cost and regisatration fee
                totalCost = lodgeCost + regFee;
                //Display output 
                outputRegistrationLabel.Text = regFee.ToString();
                outputLodgingLabel.Text = lodgeCost.ToString();
                outputTotalLabel.Text = totalCost.ToString();
            }
            else if (selection1 == 4 && selection2 == 3)
            {
                //Set variables provided that correspond with each workshop type and location
                workshopType = "How to Interview";
                numOfDays = 1;
                regFee = 500;
                workshopLocation = "Orlando";
                lodgeFee = 300;

                //Calculate lodge cost by multiplying cost per day times number of days
                lodgeCost = lodgeFee * numOfDays;
                //Calculate total by adding lodge cost and regisatration fee
                totalCost = lodgeCost + regFee;
                //Display output 
                outputRegistrationLabel.Text = regFee.ToString();
                outputLodgingLabel.Text = lodgeCost.ToString();
                outputTotalLabel.Text = totalCost.ToString();
            }
            else if (selection1 == 4 && selection2 == 4)
            {
                //Set variables provided that correspond with each workshop type and location
                workshopType = "How to Interview";
                numOfDays = 1;
                regFee = 500;
                workshopLocation = "Phoenix";
                lodgeFee = 175;

                //Calculate lodge cost by multiplying cost per day times number of days
                lodgeCost = lodgeFee * numOfDays;
                //Calculate total by adding lodge cost and regisatration fee
                totalCost = lodgeCost + regFee;
                //Display output 
                outputRegistrationLabel.Text = regFee.ToString();
                outputLodgingLabel.Text = lodgeCost.ToString();
                outputTotalLabel.Text = totalCost.ToString();
            }
            else if (selection1 == 4 && selection2 == 5)
            {
                //Set variables provided that correspond with each workshop type and location
                workshopType = "How to Interview";
                numOfDays = 1;
                regFee = 500;
                workshopLocation = "Raleigh";
                lodgeFee = 150;

                //Calculate lodge cost by multiplying cost per day times number of days
                lodgeCost = lodgeFee * numOfDays;
                //Calculate total by adding lodge cost and regisatration fee
                totalCost = lodgeCost + regFee;
                //Display output 
                outputRegistrationLabel.Text = regFee.ToString();
                outputLodgingLabel.Text = lodgeCost.ToString();
                outputTotalLabel.Text = totalCost.ToString();
            }
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void clearButton_Click(object sender, EventArgs e)
        {
            outputRegistrationLabel.Text = "";
            outputLodgingLabel.Text = "";
            outputTotalLabel.Text = "";
        }
    }
}
