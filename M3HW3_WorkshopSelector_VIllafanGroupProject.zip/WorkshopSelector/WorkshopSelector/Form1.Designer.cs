﻿namespace WorkshopSelector
{
    partial class workshopSelector
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.workshopListbox = new System.Windows.Forms.ListBox();
            this.locationListbox = new System.Windows.Forms.ListBox();
            this.calculateButton = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.outputRegistrationLabel = new System.Windows.Forms.Label();
            this.outputLodgingLabel = new System.Windows.Forms.Label();
            this.outputTotalLabel = new System.Windows.Forms.Label();
            this.clearButton = new System.Windows.Forms.Button();
            this.exitButton = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(8, 13);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(112, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Select Workshop type";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(166, 13);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(130, 13);
            this.label2.TabIndex = 1;
            this.label2.Text = "Select workshop Location";
            // 
            // workshopListbox
            // 
            this.workshopListbox.FormattingEnabled = true;
            this.workshopListbox.Items.AddRange(new object[] {
            "Handling Stress",
            "Time Management",
            "Supervision Skills",
            "Negotiation",
            "How to Interview"});
            this.workshopListbox.Location = new System.Drawing.Point(11, 51);
            this.workshopListbox.Name = "workshopListbox";
            this.workshopListbox.Size = new System.Drawing.Size(109, 95);
            this.workshopListbox.TabIndex = 2;
            // 
            // locationListbox
            // 
            this.locationListbox.FormattingEnabled = true;
            this.locationListbox.Items.AddRange(new object[] {
            "Austin",
            "Chicago",
            "Dallas",
            "Orlando",
            "Phoenix",
            "Raleigh"});
            this.locationListbox.Location = new System.Drawing.Point(169, 51);
            this.locationListbox.Name = "locationListbox";
            this.locationListbox.Size = new System.Drawing.Size(112, 95);
            this.locationListbox.TabIndex = 3;
            // 
            // calculateButton
            // 
            this.calculateButton.Location = new System.Drawing.Point(98, 164);
            this.calculateButton.Name = "calculateButton";
            this.calculateButton.Size = new System.Drawing.Size(89, 39);
            this.calculateButton.TabIndex = 4;
            this.calculateButton.Text = "Calculate Cost";
            this.calculateButton.UseVisualStyleBackColor = true;
            this.calculateButton.Click += new System.EventHandler(this.calculateButton_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(8, 225);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(66, 13);
            this.label3.TabIndex = 5;
            this.label3.Text = "Registration:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(8, 256);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(48, 13);
            this.label4.TabIndex = 6;
            this.label4.Text = "Lodging:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(8, 289);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(34, 13);
            this.label5.TabIndex = 7;
            this.label5.Text = "Total:";
            // 
            // outputRegistrationLabel
            // 
            this.outputRegistrationLabel.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.outputRegistrationLabel.Location = new System.Drawing.Point(98, 224);
            this.outputRegistrationLabel.Name = "outputRegistrationLabel";
            this.outputRegistrationLabel.Size = new System.Drawing.Size(100, 23);
            this.outputRegistrationLabel.TabIndex = 8;
            this.outputRegistrationLabel.Text = " outputRegistrationLabel";
            this.outputRegistrationLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // outputLodgingLabel
            // 
            this.outputLodgingLabel.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.outputLodgingLabel.Location = new System.Drawing.Point(98, 256);
            this.outputLodgingLabel.Name = "outputLodgingLabel";
            this.outputLodgingLabel.Size = new System.Drawing.Size(100, 23);
            this.outputLodgingLabel.TabIndex = 9;
            this.outputLodgingLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // outputTotalLabel
            // 
            this.outputTotalLabel.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.outputTotalLabel.Location = new System.Drawing.Point(98, 288);
            this.outputTotalLabel.Name = "outputTotalLabel";
            this.outputTotalLabel.Size = new System.Drawing.Size(100, 23);
            this.outputTotalLabel.TabIndex = 10;
            this.outputTotalLabel.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            // 
            // clearButton
            // 
            this.clearButton.Location = new System.Drawing.Point(45, 340);
            this.clearButton.Name = "clearButton";
            this.clearButton.Size = new System.Drawing.Size(75, 23);
            this.clearButton.TabIndex = 11;
            this.clearButton.Text = "Clear";
            this.clearButton.UseVisualStyleBackColor = true;
            this.clearButton.Click += new System.EventHandler(this.clearButton_Click);
            // 
            // exitButton
            // 
            this.exitButton.Location = new System.Drawing.Point(169, 340);
            this.exitButton.Name = "exitButton";
            this.exitButton.Size = new System.Drawing.Size(75, 23);
            this.exitButton.TabIndex = 12;
            this.exitButton.Text = "Exit";
            this.exitButton.UseVisualStyleBackColor = true;
            this.exitButton.Click += new System.EventHandler(this.exitButton_Click);
            // 
            // workshopSelector
            // 
            this.AcceptButton = this.calculateButton;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(300, 396);
            this.Controls.Add(this.exitButton);
            this.Controls.Add(this.clearButton);
            this.Controls.Add(this.outputTotalLabel);
            this.Controls.Add(this.outputLodgingLabel);
            this.Controls.Add(this.outputRegistrationLabel);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.calculateButton);
            this.Controls.Add(this.locationListbox);
            this.Controls.Add(this.workshopListbox);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "workshopSelector";
            this.Text = "Workshop Selector";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ListBox workshopListbox;
        private System.Windows.Forms.ListBox locationListbox;
        private System.Windows.Forms.Button calculateButton;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label outputRegistrationLabel;
        private System.Windows.Forms.Label outputLodgingLabel;
        private System.Windows.Forms.Label outputTotalLabel;
        private System.Windows.Forms.Button clearButton;
        private System.Windows.Forms.Button exitButton;
    }
}

