﻿namespace M2HW1_Williams
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.firstNameLabel = new System.Windows.Forms.Label();
            this.firstNameTextBox = new System.Windows.Forms.TextBox();
            this.lastNameTextBox = new System.Windows.Forms.TextBox();
            this.lastNameLabel = new System.Windows.Forms.Label();
            this.titleTextBox = new System.Windows.Forms.TextBox();
            this.titleLabel = new System.Windows.Forms.Label();
            this.middleNameTextBox = new System.Windows.Forms.TextBox();
            this.middleNameLabel = new System.Windows.Forms.Label();
            this.saveInfoButton = new System.Windows.Forms.Button();
            this.clearInfoButton = new System.Windows.Forms.Button();
            this.nameLabel = new System.Windows.Forms.Label();
            this.namePanel = new System.Windows.Forms.Panel();
            this.fullNameButton = new System.Windows.Forms.Button();
            this.fullNameTitleButton = new System.Windows.Forms.Button();
            this.firstAndLastNameButton = new System.Windows.Forms.Button();
            this.fullNameTitleCommaButton = new System.Windows.Forms.Button();
            this.fullNameCommaButton = new System.Windows.Forms.Button();
            this.firstAndLastNameCommaButton = new System.Windows.Forms.Button();
            this.namePanel.SuspendLayout();
            this.SuspendLayout();
            // 
            // firstNameLabel
            // 
            this.firstNameLabel.AutoSize = true;
            this.firstNameLabel.Location = new System.Drawing.Point(26, 33);
            this.firstNameLabel.Name = "firstNameLabel";
            this.firstNameLabel.Size = new System.Drawing.Size(60, 13);
            this.firstNameLabel.TabIndex = 3;
            this.firstNameLabel.Text = "First Name:";
            // 
            // firstNameTextBox
            // 
            this.firstNameTextBox.Location = new System.Drawing.Point(92, 30);
            this.firstNameTextBox.Name = "firstNameTextBox";
            this.firstNameTextBox.Size = new System.Drawing.Size(100, 20);
            this.firstNameTextBox.TabIndex = 0;
            // 
            // lastNameTextBox
            // 
            this.lastNameTextBox.Location = new System.Drawing.Point(92, 77);
            this.lastNameTextBox.Name = "lastNameTextBox";
            this.lastNameTextBox.Size = new System.Drawing.Size(100, 20);
            this.lastNameTextBox.TabIndex = 2;
            // 
            // lastNameLabel
            // 
            this.lastNameLabel.AutoSize = true;
            this.lastNameLabel.Location = new System.Drawing.Point(25, 80);
            this.lastNameLabel.Name = "lastNameLabel";
            this.lastNameLabel.Size = new System.Drawing.Size(61, 13);
            this.lastNameLabel.TabIndex = 2;
            this.lastNameLabel.Text = "Last Name:";
            // 
            // titleTextBox
            // 
            this.titleTextBox.Location = new System.Drawing.Point(295, 77);
            this.titleTextBox.Name = "titleTextBox";
            this.titleTextBox.Size = new System.Drawing.Size(100, 20);
            this.titleTextBox.TabIndex = 7;
            // 
            // titleLabel
            // 
            this.titleLabel.AutoSize = true;
            this.titleLabel.Location = new System.Drawing.Point(259, 80);
            this.titleLabel.Name = "titleLabel";
            this.titleLabel.Size = new System.Drawing.Size(30, 13);
            this.titleLabel.TabIndex = 6;
            this.titleLabel.Text = "Title:";
            // 
            // middleNameTextBox
            // 
            this.middleNameTextBox.Location = new System.Drawing.Point(295, 30);
            this.middleNameTextBox.Name = "middleNameTextBox";
            this.middleNameTextBox.Size = new System.Drawing.Size(100, 20);
            this.middleNameTextBox.TabIndex = 1;
            // 
            // middleNameLabel
            // 
            this.middleNameLabel.AutoSize = true;
            this.middleNameLabel.Location = new System.Drawing.Point(217, 33);
            this.middleNameLabel.Name = "middleNameLabel";
            this.middleNameLabel.Size = new System.Drawing.Size(72, 13);
            this.middleNameLabel.TabIndex = 4;
            this.middleNameLabel.Text = "Middle Name:";
            // 
            // saveInfoButton
            // 
            this.saveInfoButton.Location = new System.Drawing.Point(92, 131);
            this.saveInfoButton.Name = "saveInfoButton";
            this.saveInfoButton.Size = new System.Drawing.Size(75, 35);
            this.saveInfoButton.TabIndex = 8;
            this.saveInfoButton.Text = "Save Information";
            this.saveInfoButton.UseVisualStyleBackColor = true;
            this.saveInfoButton.Click += new System.EventHandler(this.saveInfoButton_Click);
            // 
            // clearInfoButton
            // 
            this.clearInfoButton.Location = new System.Drawing.Point(295, 131);
            this.clearInfoButton.Name = "clearInfoButton";
            this.clearInfoButton.Size = new System.Drawing.Size(75, 35);
            this.clearInfoButton.TabIndex = 9;
            this.clearInfoButton.Text = "Clear Information";
            this.clearInfoButton.UseVisualStyleBackColor = true;
            this.clearInfoButton.Click += new System.EventHandler(this.clearInfoButton_Click);
            // 
            // nameLabel
            // 
            this.nameLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.nameLabel.Location = new System.Drawing.Point(28, 197);
            this.nameLabel.Name = "nameLabel";
            this.nameLabel.Size = new System.Drawing.Size(366, 23);
            this.nameLabel.TabIndex = 10;
            this.nameLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // namePanel
            // 
            this.namePanel.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.namePanel.Controls.Add(this.firstAndLastNameCommaButton);
            this.namePanel.Controls.Add(this.fullNameCommaButton);
            this.namePanel.Controls.Add(this.fullNameTitleCommaButton);
            this.namePanel.Controls.Add(this.firstAndLastNameButton);
            this.namePanel.Controls.Add(this.fullNameButton);
            this.namePanel.Controls.Add(this.fullNameTitleButton);
            this.namePanel.Location = new System.Drawing.Point(29, 238);
            this.namePanel.Name = "namePanel";
            this.namePanel.Size = new System.Drawing.Size(365, 100);
            this.namePanel.TabIndex = 11;
            // 
            // fullNameButton
            // 
            this.fullNameButton.Location = new System.Drawing.Point(143, 13);
            this.fullNameButton.Name = "fullNameButton";
            this.fullNameButton.Size = new System.Drawing.Size(75, 37);
            this.fullNameButton.TabIndex = 1;
            this.fullNameButton.Text = "Full Name";
            this.fullNameButton.UseVisualStyleBackColor = true;
            this.fullNameButton.Click += new System.EventHandler(this.fullNameButton_Click);
            // 
            // fullNameTitleButton
            // 
            this.fullNameTitleButton.Location = new System.Drawing.Point(18, 13);
            this.fullNameTitleButton.Name = "fullNameTitleButton";
            this.fullNameTitleButton.Size = new System.Drawing.Size(75, 37);
            this.fullNameTitleButton.TabIndex = 0;
            this.fullNameTitleButton.Text = "Full Name w/ Title";
            this.fullNameTitleButton.UseVisualStyleBackColor = true;
            this.fullNameTitleButton.Click += new System.EventHandler(this.fullNameTitleButton_Click);
            // 
            // firstAndLastNameButton
            // 
            this.firstAndLastNameButton.Location = new System.Drawing.Point(264, 13);
            this.firstAndLastNameButton.Name = "firstAndLastNameButton";
            this.firstAndLastNameButton.Size = new System.Drawing.Size(75, 37);
            this.firstAndLastNameButton.TabIndex = 2;
            this.firstAndLastNameButton.Text = "First and Last Name";
            this.firstAndLastNameButton.UseVisualStyleBackColor = true;
            this.firstAndLastNameButton.Click += new System.EventHandler(this.firstAndLastNameButton_Click);
            // 
            // fullNameTitleCommaButton
            // 
            this.fullNameTitleCommaButton.Location = new System.Drawing.Point(18, 56);
            this.fullNameTitleCommaButton.Name = "fullNameTitleCommaButton";
            this.fullNameTitleCommaButton.Size = new System.Drawing.Size(75, 37);
            this.fullNameTitleCommaButton.TabIndex = 3;
            this.fullNameTitleCommaButton.Text = "Last, First, and Title";
            this.fullNameTitleCommaButton.UseVisualStyleBackColor = true;
            this.fullNameTitleCommaButton.Click += new System.EventHandler(this.fullNameTitleCommaButton_Click);
            // 
            // fullNameCommaButton
            // 
            this.fullNameCommaButton.Location = new System.Drawing.Point(143, 61);
            this.fullNameCommaButton.Name = "fullNameCommaButton";
            this.fullNameCommaButton.Size = new System.Drawing.Size(75, 37);
            this.fullNameCommaButton.TabIndex = 4;
            this.fullNameCommaButton.Text = "Last, First and Middle Name";
            this.fullNameCommaButton.UseVisualStyleBackColor = true;
            this.fullNameCommaButton.Click += new System.EventHandler(this.fullNameCommaButton_Click);
            // 
            // firstAndLastNameCommaButton
            // 
            this.firstAndLastNameCommaButton.Location = new System.Drawing.Point(264, 56);
            this.firstAndLastNameCommaButton.Name = "firstAndLastNameCommaButton";
            this.firstAndLastNameCommaButton.Size = new System.Drawing.Size(75, 37);
            this.firstAndLastNameCommaButton.TabIndex = 5;
            this.firstAndLastNameCommaButton.Text = "Last Name, First Name";
            this.firstAndLastNameCommaButton.UseVisualStyleBackColor = true;
            this.firstAndLastNameCommaButton.Click += new System.EventHandler(this.firstAndLastNameCommaButton_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(446, 394);
            this.Controls.Add(this.namePanel);
            this.Controls.Add(this.nameLabel);
            this.Controls.Add(this.clearInfoButton);
            this.Controls.Add(this.saveInfoButton);
            this.Controls.Add(this.titleTextBox);
            this.Controls.Add(this.titleLabel);
            this.Controls.Add(this.middleNameTextBox);
            this.Controls.Add(this.middleNameLabel);
            this.Controls.Add(this.lastNameTextBox);
            this.Controls.Add(this.lastNameLabel);
            this.Controls.Add(this.firstNameTextBox);
            this.Controls.Add(this.firstNameLabel);
            this.Name = "Form1";
            this.Text = "Name Formatter";
            this.namePanel.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label firstNameLabel;
        private System.Windows.Forms.TextBox firstNameTextBox;
        private System.Windows.Forms.TextBox lastNameTextBox;
        private System.Windows.Forms.Label lastNameLabel;
        private System.Windows.Forms.TextBox titleTextBox;
        private System.Windows.Forms.Label titleLabel;
        private System.Windows.Forms.TextBox middleNameTextBox;
        private System.Windows.Forms.Label middleNameLabel;
        private System.Windows.Forms.Button saveInfoButton;
        private System.Windows.Forms.Button clearInfoButton;
        private System.Windows.Forms.Label nameLabel;
        private System.Windows.Forms.Panel namePanel;
        private System.Windows.Forms.Button fullNameButton;
        private System.Windows.Forms.Button fullNameTitleButton;
        private System.Windows.Forms.Button firstAndLastNameCommaButton;
        private System.Windows.Forms.Button fullNameCommaButton;
        private System.Windows.Forms.Button fullNameTitleCommaButton;
        private System.Windows.Forms.Button firstAndLastNameButton;
    }
}

