﻿/**
* 02/18/18
* CSC 153
* Aaron Williams
* This program will display the user's name in various ways depending on the button they click.
*/

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace M2HW1_Williams
{
    public partial class Form1 : Form
    {
        //Variables for the user's name
        private string firstName;
        private string lastName;
        private string middleName;
        private string title;
        private string lastNameComma;
        private string middleNameComma;

        public Form1()
        {
            InitializeComponent();
        }

        private void saveInfoButton_Click(object sender, EventArgs e)
        {
            //Initializing variables and saving values to them.
            firstName = firstNameTextBox.Text + " ";
            lastName = lastNameTextBox.Text + " ";
            middleName = middleNameTextBox.Text + " ";
            title = titleTextBox.Text + " ";
            lastNameComma = lastNameTextBox.Text + ", ";
            middleNameComma = middleNameTextBox.Text + ", ";


        }

        private void fullNameTitleButton_Click(object sender, EventArgs e)
        {
            //Displays user's whole name with a title
            nameLabel.Text = title + firstName + middleName + lastName;
        }

        private void clearInfoButton_Click(object sender, EventArgs e)
        {
            //Clears name display
            nameLabel.Text = "";
        }

        private void fullNameButton_Click(object sender, EventArgs e)
        {
            //Displays user's whole name
            nameLabel.Text = firstName + middleName + lastName;
        }

        private void firstAndLastNameButton_Click(object sender, EventArgs e)
        {
            //Displays user's first and last names
            nameLabel.Text = firstName + lastName;
        }

        private void fullNameTitleCommaButton_Click(object sender, EventArgs e)
        {
            //Displays user's whole name with a title separated by commas
            nameLabel.Text = lastNameComma + firstName + middleNameComma + title;
        }

        private void fullNameCommaButton_Click(object sender, EventArgs e)
        {
            //Displays user's whole name separated by commas
            nameLabel.Text = lastNameComma + firstName + middleName;
        }

        private void firstAndLastNameCommaButton_Click(object sender, EventArgs e)
        {
            //Displays user's first and last names separated by commas
            nameLabel.Text = lastNameComma + firstName;
        }
    }
}
