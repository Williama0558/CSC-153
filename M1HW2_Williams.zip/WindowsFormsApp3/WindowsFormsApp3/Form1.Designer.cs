﻿namespace WindowsFormsApp3
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.cardNameLabel = new System.Windows.Forms.Label();
            this.eightOfDiamonds = new System.Windows.Forms.PictureBox();
            this.blackJoker = new System.Windows.Forms.PictureBox();
            this.aceOfSpades = new System.Windows.Forms.PictureBox();
            this.kingOfSpades = new System.Windows.Forms.PictureBox();
            this.twoOfClubs = new System.Windows.Forms.PictureBox();
            this.label1 = new System.Windows.Forms.Label();
            this.exitButton = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.eightOfDiamonds)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.blackJoker)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.aceOfSpades)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.kingOfSpades)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.twoOfClubs)).BeginInit();
            this.SuspendLayout();
            // 
            // cardNameLabel
            // 
            this.cardNameLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.cardNameLabel.Location = new System.Drawing.Point(12, 144);
            this.cardNameLabel.Name = "cardNameLabel";
            this.cardNameLabel.Size = new System.Drawing.Size(338, 23);
            this.cardNameLabel.TabIndex = 11;
            this.cardNameLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // eightOfDiamonds
            // 
            this.eightOfDiamonds.Image = ((System.Drawing.Image)(resources.GetObject("eightOfDiamonds.Image")));
            this.eightOfDiamonds.Location = new System.Drawing.Point(12, 59);
            this.eightOfDiamonds.Name = "eightOfDiamonds";
            this.eightOfDiamonds.Size = new System.Drawing.Size(50, 70);
            this.eightOfDiamonds.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.eightOfDiamonds.TabIndex = 10;
            this.eightOfDiamonds.TabStop = false;
            this.eightOfDiamonds.Click += new System.EventHandler(this.eightOfDiamonds_Click);
            // 
            // blackJoker
            // 
            this.blackJoker.Image = ((System.Drawing.Image)(resources.GetObject("blackJoker.Image")));
            this.blackJoker.Location = new System.Drawing.Point(300, 59);
            this.blackJoker.Name = "blackJoker";
            this.blackJoker.Size = new System.Drawing.Size(50, 70);
            this.blackJoker.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.blackJoker.TabIndex = 9;
            this.blackJoker.TabStop = false;
            this.blackJoker.Click += new System.EventHandler(this.blackJoker_Click);
            // 
            // aceOfSpades
            // 
            this.aceOfSpades.Image = ((System.Drawing.Image)(resources.GetObject("aceOfSpades.Image")));
            this.aceOfSpades.Location = new System.Drawing.Point(228, 59);
            this.aceOfSpades.Name = "aceOfSpades";
            this.aceOfSpades.Size = new System.Drawing.Size(50, 70);
            this.aceOfSpades.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.aceOfSpades.TabIndex = 8;
            this.aceOfSpades.TabStop = false;
            this.aceOfSpades.Click += new System.EventHandler(this.aceOfSpades_Click);
            // 
            // kingOfSpades
            // 
            this.kingOfSpades.Image = ((System.Drawing.Image)(resources.GetObject("kingOfSpades.Image")));
            this.kingOfSpades.Location = new System.Drawing.Point(162, 59);
            this.kingOfSpades.Name = "kingOfSpades";
            this.kingOfSpades.Size = new System.Drawing.Size(50, 70);
            this.kingOfSpades.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.kingOfSpades.TabIndex = 7;
            this.kingOfSpades.TabStop = false;
            this.kingOfSpades.Click += new System.EventHandler(this.kingOfSpades_Click);
            // 
            // twoOfClubs
            // 
            this.twoOfClubs.Image = ((System.Drawing.Image)(resources.GetObject("twoOfClubs.Image")));
            this.twoOfClubs.Location = new System.Drawing.Point(85, 59);
            this.twoOfClubs.Name = "twoOfClubs";
            this.twoOfClubs.Size = new System.Drawing.Size(50, 70);
            this.twoOfClubs.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.twoOfClubs.TabIndex = 6;
            this.twoOfClubs.TabStop = false;
            this.twoOfClubs.Click += new System.EventHandler(this.twoOfClubs_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(81, 25);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(202, 20);
            this.label1.TabIndex = 12;
            this.label1.Text = "Click a card to see its name";
            // 
            // exitButton
            // 
            this.exitButton.Location = new System.Drawing.Point(153, 186);
            this.exitButton.Name = "exitButton";
            this.exitButton.Size = new System.Drawing.Size(75, 35);
            this.exitButton.TabIndex = 13;
            this.exitButton.Text = "Exit";
            this.exitButton.UseVisualStyleBackColor = true;
            this.exitButton.Click += new System.EventHandler(this.exitButton_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(379, 259);
            this.Controls.Add(this.exitButton);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.cardNameLabel);
            this.Controls.Add(this.eightOfDiamonds);
            this.Controls.Add(this.blackJoker);
            this.Controls.Add(this.aceOfSpades);
            this.Controls.Add(this.kingOfSpades);
            this.Controls.Add(this.twoOfClubs);
            this.Name = "Form1";
            this.Text = "Card Identifier";
            ((System.ComponentModel.ISupportInitialize)(this.eightOfDiamonds)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.blackJoker)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.aceOfSpades)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.kingOfSpades)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.twoOfClubs)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label cardNameLabel;
        private System.Windows.Forms.PictureBox eightOfDiamonds;
        private System.Windows.Forms.PictureBox blackJoker;
        private System.Windows.Forms.PictureBox aceOfSpades;
        private System.Windows.Forms.PictureBox kingOfSpades;
        private System.Windows.Forms.PictureBox twoOfClubs;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button exitButton;
    }
}

