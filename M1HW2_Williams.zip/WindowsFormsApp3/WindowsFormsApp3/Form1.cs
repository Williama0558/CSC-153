﻿/**
* 02/04/18
* CSC 153
* Aaron Williams
* This program will show the user names of five cards
*/

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp3
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        //Displays the card name to the user
        private void eightOfDiamonds_Click(object sender, EventArgs e)
        {
            cardNameLabel.Text = "Eight of Diamonds";
        }

        private void twoOfClubs_Click(object sender, EventArgs e)
        {
            cardNameLabel.Text = "Two of Clubs";
        }

        private void kingOfSpades_Click(object sender, EventArgs e)
        {
            cardNameLabel.Text = "King of Spades";
        }

        private void aceOfSpades_Click(object sender, EventArgs e)
        {
            cardNameLabel.Text = "Ace of Spades";
        }

        private void blackJoker_Click(object sender, EventArgs e)
        {
            cardNameLabel.Text = "Black Joker";
        }

        //Exits the program
        private void exitButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
